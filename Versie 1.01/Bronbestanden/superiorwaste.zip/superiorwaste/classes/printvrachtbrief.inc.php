<?php
     require_once(CLASSES_PATH . "uitgifte.inc.php");

class clsPrintVrachtbrief extends clsUitgifte
{        
     public function __construct() 
     {    parent::__construct();
          
          $column = new clsColumn();
          $column->setFieldName("ID");
          $column->setCaption("Vrachtbriefnummer");
          $column->setReadOnly();
          $this->columnheader->addColumn($column); 
          
          $column = new clsLookupColumn();
          $column->setFieldName("OnderdeelID");
          $column->setCaption("Onderdeel");
          $column->setLookUpSql("SELECT Naam as lookupresult, ID as lookup_id
                                   FROM onderdelen 
                                  ORDER BY Naam");
          $this->columnheader->replaceColumn("OnderdeelID", $column); 
     }  
     
     public function getPrintHtml()
     {    $uitgifteid = $_GET["uitgifte"];
          $rows = $this->connection->query($this->getSelectSql(" WHERE uitgiftes.ID = " . $uitgifteid));
          
          foreach ($rows as $dbrow) 
          {    $row = $this->convertFromTableRow($dbrow);
               break;
          }
          $output = "<table class='table'>
                          <tr>
                               <td colspan='3'>
                                    <h1>Superior Waste - ReMas</h1>
                               </td>
                          </tr> 
                          <tr>
                               <td colspan='3'>
                                    <h2>Vrachtbrief</h2>
                               </td>
                          </tr>";
          
          $column = $this->getColumnHeader()->findColumn("Tijdstip");
          $output .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $column = $this->getColumnHeader()->findColumn("MedewerkerID");
          $output .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $column = $this->getColumnHeader()->findColumn("ID");
          $output .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $column = $this->getColumnHeader()->findColumn("OnderdeelID");
          $output .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $column = $this->getColumnHeader()->findColumn("GewichtKg");
          $output .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $output .= "</table>";
          
          return $output;
     }
}

?>