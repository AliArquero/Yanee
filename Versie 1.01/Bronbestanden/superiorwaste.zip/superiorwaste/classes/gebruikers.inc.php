<?php
     require_once(CLASSES_PATH . "table.inc.php");	

class clsGebruiker extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, RolID, Naam, Wachtwoord, Emailadres 
                                FROM medewerkers";
          $this->ordersql = "ORDER BY Naam";
          $this->tablename = "medewerkers";
          $this->key = "ID";
          $this->tabletitle = "Gebruikers";

          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Naam");
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Wachtwoord");
          $column->setCaption("Wachtwoord");
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Emailadres");
          $column->setCaption("Emailadres");
          $column->setEditType("Email");
          $this->columnheader->addColumn($column);
          
          $column = new clsLookupColumn();
          $column->setFieldName("RolID");
          $column->setCaption("Rol");
          $column->setLookUpSql("SELECT CONCAT(Naam, ' - ', Omschrijving) as lookupresult, ID as lookup_id
                                   FROM rollen 
                                 ORDER BY Naam");
          $this->columnheader->addColumn($column);         
     }  
}
?>