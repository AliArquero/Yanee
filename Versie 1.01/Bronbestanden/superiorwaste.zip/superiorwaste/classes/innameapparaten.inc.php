<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsInnameApparaat extends clsTableDef
{    
     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, InnameID, ApparaatID as AID, ApparaatID as AVergoeding
                                FROM innameapparaat";
          $this->tablename = "innameapparaat";
          $this->key = "ID";
          $this->tabletitle = "Ingenomen";

          $column = new clsLookupColumn();
          $column->setFieldName("AID");
          $column->setCaption("Apparaat");
          $column->setLookUpSql("SELECT Naam as lookupresult, ID as lookup_id
                                   FROM apparaten 
                                 ORDER BY Naam");
          $this->columnheader->addColumn($column);        
          
          $column = new clsLookupMoneyColumn();
          $column->setFieldName("AVergoeding");
          $column->setCaption("Vergoeding");
          $column->setLookUpSql("SELECT Vergoeding as lookupresult, ID as lookup_id
                                   FROM apparaten 
                                 ORDER BY Naam");
          $this->columnheader->addColumn($column);           
     }     
}
?>