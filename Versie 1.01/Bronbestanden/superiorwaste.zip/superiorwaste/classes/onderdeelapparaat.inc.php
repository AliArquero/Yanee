<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsOnderdeelApparaat extends clsTableDef
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, OnderdeelID, ApparaatID, Percentage
                                FROM onderdeelapparaat";
          $this->tablename = "onderdeelapparaat";
          $this->key = "ID";
          $this->tabletitle = "Onderdelen voor dit apparaat";
          $this->setSaveDialogButtons(new clsSaveDialogButton('button_grapp_ok', 'check', ''), 
                                      new clsSaveDialogButton('button_grapp_cancel', 'close', '')
                                     );

          $column = new clsLookupColumn();
          $column->setFieldName("OnderdeelID");
          $column->setCaption("Onderdeel");
          $column->setLookUpSql("SELECT Concat(Naam, ' - ' , Omschrijving) as lookupresult, ID as lookup_id
                                   FROM onderdelen 
                                 ORDER BY Naam");
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("Percentage");
          $column->setCaption("% van het gewicht");
          $column->setDecimals(0);
          $this->columnheader->addColumn($column);
          
     }
     
     public function getEditHtml()
     {
          $output = $this->getFormControlsHtml() .
                    $this->makeSaveDialog();
          return $output;
     }

     protected function updateDetails()
     {
		$masterid = $_POST["MasterID"];
		if (!$masterid)
		{    $masterid = $this->connection->lastInsertId();
		}
		$nieuweappids = $_POST['NieuweAppIDs'];
		$ids = $_POST['IDs'];
		
		
		if (isset($masterid))
          { // Er zijn details    
               $sql = "DELETE FROM innameapparaat
                        WHERE InnameID = " . $masterid;
               if (isset($ids) && ($ids != ""))
               {    $sql .= " 
                        AND   (ID NOT IN (" . $ids . "))";
               }
               if ($this->connection->query($sql) != true)
               {     return array("danger", $sql);
               }
               
               if (isset($nieuweappids) && ($nieuweappids != ""))
               {    $nieuweappids = explode(",", $nieuweappids);
                    foreach ($nieuweappids as $appid)
                    {    $sql = "INSERT INTO innameapparaat
                                             (InnameID, ApparaatID) 
                                      VALUES (" . $masterid . "," . $appid . ")";  
                         if ($this->connection->query($sql) != true)
                         {
                              return array("danger", $sql);
                         }
                    }
               }
          }
          return array("success");
     }
}

class clsApparaatSpecs extends clsTableDef
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT oa.ID AS GID, OnderdeelID, oa.ApparaatID AS AID, 
                                     oa.Percentage AS Percentage,
                                     ROUND((oa.Percentage * a.GewichtGram) / 100, 0) AS Gewicht,
                                     o.VoorraadKg AS Voorraad                                     
                                FROM onderdeelapparaat oa LEFT JOIN apparaten a 
                                                                 ON a.ID = oa.ApparaatID
                                                          LEFT JOIN onderdelen o 
                                                                 ON o.ID = oa.OnderdeelID";
          $this->tablename = "onderdeelapparaat";
          $this->key = "GID";
          $this->tabletitle = "Onderdelen voor dit apparaat";
          $this->savedialogbuttons = array(new clsSaveDialogButton('apparaatspecs_button_save', 'check', ''), 
                                           new clsSaveDialogButton('apparaatspecs_button_cancel', 'close', '')
                                          );

          $column = new clsLookupColumn();
          $column->setFieldName("OnderdeelID");
          $column->setCaption("Onderdeel");
          $column->setLookUpSql("SELECT Naam as lookupresult, ID as lookup_id
                                   FROM onderdelen 
                                 ORDER BY Naam");
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("Percentage");
          $column->setCaption("Gewicht %");
          $column->setDecimals(0);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("Gewicht");
          $column->setCaption("Gewicht gram");
          $column->setDecimals(0);
          $column->setReadOnly();
          $this->columnheader->addColumn($column);         
     }
}

?>