<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsRapport extends clsTableDef
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, Active, Titel, Omschrijving, SQLText 
                                FROM rapporten";
          $this->ordersql = "ORDER BY Titel";
          $this->tablename = "rapporten";
          $this->key = "ID";
          $this->tabletitle = "Rapporten";
          
          $column = new clsColumn();
          $column->setFieldName("Active");
          $column->setCaption("Actief");
          $this->columnheader->addColumn($column);

          $column = new clsColumn();
          $column->setFieldName("Titel");
          $column->setCaption("Titel");
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("Omschrijving");
          $this->columnheader->addColumn($column);
          
          $column = new clsSQLColumn();
          $column->setFieldName("SQLText");
          $column->setCaption("SQL");
          $this->columnheader->addColumn($column);
     }  
}

class clsSQLColumn extends clsTextColumn
{
     public function getFieldValueFromDBFormat($row)
     {    return str_replace("^", "'", str_replace('~', '"', $row[$this->getFieldName()]));
     } 
     
     public function setFieldValueToDBFormat($sql)
     {    return str_replace("'", "^", str_replace("'", "~", $sql));
     }    
}

?>