<?php
     require_once(CLASSES_PATH . "table.inc.php");
	require_once(CLASSES_PATH . "apparaten.inc.php");
	require_once(CLASSES_PATH . "innameapparaten.inc.php");

class clsInnameWijzigen extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, MedewerkerID, Tijdstip
                                FROM innames";
          $this->ordersql = "ORDER BY Tijdstip DESC";
          $this->tablename = "innames";
          $this->key = "ID";
          $this->tabletitle = "Inname";
          
          $column = new clsLookupColumn();
          $column->setFieldName("MedewerkerID");
          $column->setCaption("Medewerker");
          $column->setLookUpSql("SELECT Naam as lookupresult, ID as lookup_id
                                   FROM medewerkers 
                                  ORDER BY Naam");
          $this->columnheader->addColumn($column); 
                                    
          $column = new clsDateTimeColumn();
          $column->setFieldName("Tijdstip");
          $column->setCaption("Tijdstip ontvangst");   
          $column->setEditType("Date and time");
          $column->setFormControlClass("datetime_control");
          $format = "d-m-Y H:i";
          $column->setFormat($format);
          $column->setDefaultValue(date($format)); //[[329]]
          $this->columnheader->addColumn($column); 
     }
     
     protected function updateDetails()
     {
		$masterid = $_POST["MasterID"];
		if (!$masterid)
		{    $masterid = $this->connection->lastInsertId();
		}
		$nieuweappids = $_POST['NieuweAppIDs'];
		$ids = $_POST['IDs'];
		
		
		if (isset($masterid))
          { // Er zijn details    
               $sql = "DELETE FROM innameapparaat
                        WHERE InnameID = " . $masterid;
               if (isset($ids) && ($ids != ""))
               {    $sql .= " 
                        AND   (ID NOT IN (" . $ids . "))";
               }
               if ($this->connection->query($sql) != true)
               {     return array("danger", $sql);
               }
               
               if (isset($nieuweappids) && ($nieuweappids != ""))
               {    $nieuweappids = explode(",", $nieuweappids);
                    foreach ($nieuweappids as $appid)
                    {    $sql = "INSERT INTO innameapparaat
                                             (InnameID, ApparaatID) 
                                      VALUES (" . $masterid . "," . $appid . ")";  
                         if ($this->connection->query($sql) != true)
                         {
                              return array("danger", $sql);
                         }
                    }
               }
          }
          return array("success");
     }
     
     public function getEditHtml()
     {    $apparaat = new clsApparaatSmall();
          $apparaat->setGridActions(array(new clsGridAction('button_inname', 'mail-forward', 'disabled')));
          $apparaat->setGridClass('apparaat');

          $ingenomen = new clsInnameApparaat();
          $ingenomen->setGridActions(array(new clsGridAction('button_remove', 'mail-reply', 'disabled'),
                                           new clsGridAction('button_remove_all', 'mail-reply-all')));
          $ingenomen->setGridClass('ingenomen');
          $ingenomen->setMaster($this, 'InnameID');

          $output = '<div class="well well-sm col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                          $this->getFormControlsHtml() . 
                     '</div>';
          $output .= '<div class="row">';
          $output .=      '<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">' .
                                $apparaat->getGridHtml() . 
                          '</div>';
          $output .=      '<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">' .
                                $ingenomen->getGridHtml() . 
                          '</div>';
          $output .=      '<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                Totaalbedrag<br><span id="ingenomen_totaal">.....</span>  
                           </div>';
          $output .= '</div><br>';
          $output .= '<div class="well well-sm col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                           $this->makeSaveDialog() .
                     '</div>';
          
          $output .=  '<script src="' . JS_PATH . 'inname.js?ver<%=' . microtime() . '%>"></script>'; //reload custom js on every pageload
                      
          return $output;
     }
     //[[343]] Begin
     protected function getFormControlsHtml()
     { 
          $output = "";
          foreach ($this->getColumnHeader()->getColumns() as $column)
          {    $fieldname = $column->getFieldName();
               $name = $fieldname . "_id";
               $output .= '<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">' .
                                $column->makeInput($name).
                          '</div>';
          }
          return $output;
     } 
     //[[343]] Einde
}

class clsInname extends clsInnameWijzigen
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->gridactions = array();
          $this->savedialogbuttons = array(new clsSaveDialogButton('button_cancel', 'times', 'Annuleren'),
                                           new clsSaveDialogButton('print_inname_bon', 'print', 'Innemen en bon afdrukken')
                                          );
     }
     
     protected function getTableRowsHtml($row)
     {    return "";
     }
}

?>