<?php
     require_once(CLASSES_PATH . "table.inc.php");
     require_once(CLASSES_PATH . "innameapparaten.inc.php");
     require_once(CLASSES_PATH . "uitgifte.inc.php");
    
class clsRapportage extends clsTableDef
{    private $rapportnr;
     private $rapport;
     
     public function __construct($rapportnr = -1) 
     {
          parent::__construct();
          
          $this->rapportnr = $rapportnr;
          switch ($this->rapportnr)
          {    case 1: $this->rapport = new clsRapportInkoop();
                       break;
               case 2: $this->rapport = new clsRapportWerkvoorraad();
                       break;
               case 3: $this->rapport = new clsRapportVerkoop();
                       break;
               case 4: $this->rapport = new clsRapportRendement();
                       break;
          }
          $this->gridactions = array();
          $this->savedialogbuttons = array(new clsSaveDialogButton('button_rapport_print', 'print', ''));
     } 
     
     public function getRapport()
     {    return $this->rapport;
     }
         
     protected function getRapportNummer()
     {    return $this->rapportnr;
     }
         
     public function getPrintHtml()
     {    $output = '<form id="rapport_form" method="POST" role="form" 
                           action="printpage.php" 
                           target="_blank">';
          $output .= $this->rapport->getParameterForm() . '
                          <div class="invisible">
                               <input type="text" 
                                      id="rapportnr"
                                      name="rapportnr"
                                      value="' . $this->getRapportNummer() . '">
                          </div>
                     </form>';
          return $output .
                 '<script src="' . JS_PATH . 'rapportage.js?ver<%=' . microtime() . '%>"></script>'; //reload custom js on every pageload
     }
}
     
class clsRapportInkoop extends clsRapportage
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->gridactions = array();
          $this->savedialogbuttons = array();
          $this->setTablename = "rapportage";
          $this->setTableTitle("Ingenomen apparaten per maand over de afgelopen 6 maanden");
     }
     
     public function setTableDef()
     {    $this->key = "IID";
          $sql = "SELECT DATE_FORMAT(i.Tijdstip, '%m-%Y') AS Maand, ";
         
          $this->setSelectSql("SELECT a.Naam AS Apparaat, ia.ID AS IID,
                                      SUM(DATE_FORMAT(i.Tijdstip, '%Y%m') = DATE_FORMAT(curdate(), '%Y%m')) AS M0,
                                      SUM(DATE_FORMAT(i.Tijdstip, '%Y%m') = DATE_FORMAT(DATE_SUB(curdate(), INTERVAL 1 MONTH), '%Y%m')) AS M1,
                                      SUM(DATE_FORMAT(i.Tijdstip, '%Y%m') = DATE_FORMAT(DATE_SUB(curdate(), INTERVAL 2 MONTH), '%Y%m')) AS M2,
                                      SUM(DATE_FORMAT(i.Tijdstip, '%Y%m') = DATE_FORMAT(DATE_SUB(curdate(), INTERVAL 3 MONTH), '%Y%m')) AS M3,
                                      SUM(DATE_FORMAT(i.Tijdstip, '%Y%m') = DATE_FORMAT(DATE_SUB(curdate(), INTERVAL 4 MONTH), '%Y%m')) AS M4,
                                      SUM(DATE_FORMAT(i.Tijdstip, '%Y%m') = DATE_FORMAT(DATE_SUB(curdate(), INTERVAL 5 MONTH), '%Y%m')) AS M5
                                 FROM innameapparaat ia 
                                      LEFT JOIN innames i ON ia.InnameID = i.ID 
                                      LEFT JOIN apparaten a ON ia.ApparaatID = a.ID
                             GROUP BY ia.ApparaatID 
                             ORDER BY a.Naam");
          $column = new clsColumn();
          $column->setFieldName("Apparaat");
          $column->setCaption("Apparaat / Maand");
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("M0");
          $column->setCaption(date("Ym"));
          $column->setDecimals(0);
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("M1");
          $column->setCaption(date("Ym", strtotime("-1 months")));
          $column->setDecimals(0);
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("M2");
          $column->setCaption(date("Ym", strtotime("-2 months")));
          $column->setDecimals(0);
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("M3");
          $column->setCaption(date("Ym", strtotime("-3 months")));
          $column->setDecimals(0);
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("M4");
          $column->setCaption(date("Ym", strtotime("-4 months")));
          $column->setDecimals(0);
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
     }
          
     public function getParameterForm()
     {    $output = '<div class="form-group col-xs-6 col-sm-6 col-md-6 col-lg-6">
                          <label>' . $this->getTableTitle() . '
                          </label><br>
                          <button class="btn btn-success" id="button_rapport_print">
                               <span class="fa fa-print">
                               </span>
                          </button>
                     </div>';
          return $output;            
     }
     
     protected function getTotalsHtml()
     {    $colM0 = $this->getColumnHeader()->findColumn("M0");
          $colM1 = $this->getColumnHeader()->findColumn("M1");
          $colM2 = $this->getColumnHeader()->findColumn("M2");
          $colM3 = $this->getColumnHeader()->findColumn("M3");
          $colM4 = $this->getColumnHeader()->findColumn("M4");
          
          $output = "<tr>
                           <td><br>Totaal
                           </td>
                           <td " . $colM0->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colM0->getDisplaySum() . "
                           </td>
                           <td " . $colM1->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colM1->getDisplaySum() . "
                           </td>
                           <td " . $colM2->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colM2->getDisplaySum() . "
                           </td>
                           <td " . $colM3->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colM3->getDisplaySum() . "
                           </td>
                           <td " . $colM4->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colM4->getDisplaySum() . "
                           </td> "; 
          $output .= "
                      </tr>";
          return $output;
     }

}
class clsRapportWerkvoorraad extends clsRapportage
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->gridactions = array();
          $this->savedialogbuttons = array();
          $this->setTablename = "rapportage";
          $this->setTableTitle("Werkvoorraad te demonteren apparaten");
     }
     
     public function setTableDef()
     {
          $this->key = "IID";
          $apparaatid = $_POST['apparaat_id'];
          $sql = "
                 SELECT DATE_FORMAT(i.Tijdstip, '%d-%m-%Y') AS Datum, COUNT(*) AS Aantal,
                        a.Naam AS Naam, a.Omschrijving AS Omschrijving,
                        i.ID AS IID
                   FROM innameapparaat ia 
                        LEFT JOIN innames i 
                               ON ia.InnameID = i.ID 
                        LEFT JOIN apparaten a 
                               ON ia.ApparaatID = a.ID
                  WHERE (ontleed IS NULL) ";
          if ($apparaatid != "")
          {    $sql .= "AND (a.ID = " . $apparaatid . ") ";
          }
          $sql .= "
                  GROUP BY ia.ApparaatID, DATE_FORMAT(i.Tijdstip, '%d-%m-%Y')
                  ORDER BY i.Tijdstip, a.Naam";
          $this->setSelectSql($sql);
          
          $column = new clsColumn();
          $column->setFieldName("Datum");
          $column->setCaption("Datum inname");
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("Aantal");
          $column->setCaption("Aantal ingenomen");
          $column->setDecimals(0);
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);

          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Apparaat");
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("");
          $column->setPrintColumnWidth(4);
          $this->columnheader->addColumn($column);
          
     }
     
     public function getParameterForm()
     {    $apparaten = new clsInnameApparaat();
          $column = $apparaten->getColumnHeader()->findColumn("AID");
          $column->setNullOption("--- Alles ---");
          $output = '<div class="form-group col-xs-4 col-sm-4 col-md-4 col-lg-4">
                          <label for="apparaat_id">' . $this->getTableTitle() . '
                          </label><br><br>' .
                    $column->makeInput("apparaat_id") . '<br>
                          <button class="btn btn-success" id="button_rapport_print">
                               <span class="fa fa-print">
                               </span>
                          </button>
                     </div>';
          return $output;            
     }

}
class clsRapportVerkoop extends clsRapportage
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->gridactions = array();
          $this->savedialogbuttons = array();
          $this->setTablename = "rapportage";
          $this->setTableTitle("Verkochte onderdelen per periode");
     }
     
     public function setTableDef()
     {    $this->key = "UID";
          $maandnr = $_POST['maandnr'];
          $onderdeelid = $_POST['onderdeel_id'];
          $sql = "SELECT DATE_FORMAT(u.Tijdstip, '%m-%Y') AS Maand, 
                         SUM(GewichtKg) AS Hoeveelheid,
                         SUM(Prijs) AS Prijs,
                         o.Naam AS Naam, 
                         o.Omschrijving AS Omschrijving,
                         u.ID AS UID
                    FROM uitgiftes u  
                         LEFT JOIN onderdelen o 
                                ON u.OnderdeelID = o.ID 
                   WHERE (DATE_FORMAT(u.Tijdstip, '%Y%m') = " . $maandnr . ") ";
          if ($onderdeelid != "")
          {    $sql .= " AND (u.OnderdeelID = " . $onderdeelid . ") ";
          };
          $sql .= "
                  GROUP BY u.OnderdeelID, DATE_FORMAT(u.Tijdstip, '%m-%Y')
                  ORDER BY u.Tijdstip, o.Naam";
                
          $this->setTableTitle("Verkochte onderdelen voor de maand " . $maandnr);
          $this->setSelectSql($sql);
          
          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Onderdeel");
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("");
          $column->setPrintColumnWidth(4);
          $this->columnheader->addColumn($column);

          
          $column = new clsNumberColumn();
          $column->setFieldName("Hoeveelheid");
          $column->setCaption("Hoeveelheid (kg)");
          $column->setDecimals(0);
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);

          $column = new clsMoneyColumn();
          $column->setFieldName("Prijs");
          $column->setCaption("Totaal ontvangen");
          $column->setDecimals(2);
          $column->setPrintColumnWidth(1);
          $this->columnheader->addColumn($column);
     }
     
     public function getParameterForm()
     {    $apparaten = new clsUitgifteWijzigen();
          $column = $apparaten->getColumnHeader()->findColumn("OnderdeelID");
          $column->setNullOption("--- Alles ---");
          $output = '<div class="form-group col-xs-4 col-sm-4 col-md-4 col-lg-4">
                          <label for="onderdeel_id">' . $this->getTableTitle() . '
                          </label><br><br>' .
                    $column->makeInput("onderdeel_id") . '<br>
                          <label for="maandnr">Maand
                          </label>
                          <input type="text" 
                                 class="form-control sql_parameter"
                                 id="maandnr"
                                 name="maandnr"
                                 value=' . date("Ym") . '><br>
                          <button class="btn btn-success" id="button_rapport_print">
                               <span class="fa fa-print">
                               </span>
                          </button>
                     </div>';
          return $output;            
     }
     
     protected function getTotalsHtml()
     {    $colhoeveelheid = $this->getColumnHeader()->findColumn("Hoeveelheid");
          $colprijs = $this->getColumnHeader()->findColumn("Prijs");
          $output = "<tr>
                           <td><br>Totaal
                           </td>
                           <td colspan='2'" . $colhoeveelheid->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colhoeveelheid->getDisplaySum() . "
                           </td>
                           <td " . $colprijs->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colprijs->getDisplaySum() . "
                           </td>
                      </tr>";
          return $output;
     }


}   
class clsRapportRendement extends clsRapportage
{    
     public function __construct() 
     {
          parent::__construct();
          
          $this->gridactions = array();
          $this->savedialogbuttons = array();
          $this->setTablename = "rapportage";
          $this->setTableTitle("Rendementoverzicht per periode");
     }
     
     public function setTableDef()
     {    $this->key = "AID";
          $maandnr = $_POST['maandnr'];
          $apparaatid = $_POST['apparaat_id'];
          $sql = "SELECT DATE_FORMAT(Tijdstip, '%Y%m') AS Maand, a.Naam as Apparaat,
                         SUM(a.Vergoeding) as Uitbetaald, 
                         SUM(ROUND((a.GewichtGram * oa.Percentage * o.HistOpbrengstPerKg  ) / 100000, 2)) as Ontvangen,
                         a.ID AS AID
                         FROM innameapparaat ia 
                              LEFT JOIN innames i ON ia.InnameID = i.ID 
                              LEFT JOIN apparaten a ON ia.ApparaatID = a.ID
                              LEFT JOIN onderdeelapparaat oa ON ia.ApparaatID = oa.ApparaatID
                              LEFT JOIN (SELECT o.ID AS OID, 
                                                ROUND(SUM(u.Prijs) / SUM(u.GewichtKg), 2) AS HistOpbrengstPerKg  
                                           FROM onderdelen o LEFT JOIN uitgiftes u ON o.ID = u.OnderdeelID
                                       GROUP BY o.ID
                                       ORDER BY o.ID) o ON oa.OnderdeelID = o.OID
                   WHERE (ia.Ontleed IS NOT NULL) ";
          if ($maandnr != "")
          {    $sql .= "AND (DATE_FORMAT(Tijdstip, '%Y%m') = " . $maandnr. ") ";
          };
          if ($apparaatid != "")
          {    $sql .= "AND (a.ID = " . $apparaatid. ") ";
          };
          $sql .= "
                GROUP BY DATE_FORMAT(Tijdstip, '%Y%m'), ia.ApparaatID
                ORDER BY DATE_FORMAT(Tijdstip, '%Y%m') DESC, Apparaat ";
          $this->setSelectSql($sql);
          $this->setTableTitle("Rendementoverzicht voor de maand " . $maandnr);
          
          $column = new clsColumn();
          $column->setFieldName("Apparaat");
          $column->setCaption("Apparaat");
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);
          
          $column = new clsMoneyColumn();
          $column->setFieldName("Uitbetaald");
          $column->setCaption("Uitbetaald");
          $column->setDecimals(2);
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);
          
          $column = new clsMoneyColumn();
          $column->setFieldName("Ontvangen");
          $column->setCaption("Gemiddelde historische opbrengst");
          $column->setDecimals(2);
          $column->setPrintColumnWidth(2);
          $this->columnheader->addColumn($column);
     }
     
     public function getParameterForm()
     {    $apparaten = new clsInnameApparaat();
          $column = $apparaten->getColumnHeader()->findColumn("AID");
          $column->setNullOption("--- Alles ---");
          $output = '<div class="form-group col-xs-4 col-sm-4 col-md-4 col-lg-4">
                          <label for="apparaat_id">' . $this->getTableTitle() . '
                          </label><br><br>' .
                    $column->makeInput("apparaat_id") . '<br>
                          <label for="maandnr">Maand
                          </label>
                          <input type="text" 
                                 class="form-control sql_parameter"
                                 id="maandnr"
                                 name="maandnr"
                                 value=' . date("Ym") . '><br>
                          <button class="btn btn-success" id="button_rapport_print">
                               <span class="fa fa-print">
                               </span>
                          </button>
                     </div>';
          return $output;            
     }
     
     protected function getTotalsHtml()
     {    $colbetaald = $this->getColumnHeader()->findColumn("Uitbetaald");
          $colontvangen = $this->getColumnHeader()->findColumn("Ontvangen");
          $output = "<tr>
                           <td><br>Totaal
                           </td>
                           <td " . $colbetaald->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colbetaald->getDisplaySum() . "
                           </td>
                           <td " . $colontvangen->getColumnHeaderClass() . " style='border-top:1pt solid black;'><br>" . $colontvangen->getDisplaySum() . "
                           </td>
                      </tr>";
          return $output;
     }


}   
?>