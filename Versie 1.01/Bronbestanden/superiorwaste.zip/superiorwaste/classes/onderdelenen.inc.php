<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsOnderdeel extends clsTableDef
{    
     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, Naam, Omschrijving, PrijsPerKg 
                                FROM onderdelen";
          $this->ordersql = "ORDER BY Naam";
          $this->tablename = "onderdelen";
          $this->key = "ID";
          $this->tabletitle = "Onderdelen";

          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Naam");
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("Omschrijving");
          $this->columnheader->addColumn($column);
          
          $column = new clsMoneyColumn();
          $column->setFieldName("PrijsPerKg");
          $column->setCaption("Verkoopprijs/kg");
          $this->columnheader->addColumn($column);         
     }  
}
?>