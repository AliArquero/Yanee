<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsPrintBon extends clsTableDef
{        
     public function __construct() 
     {    parent::__construct();
          $this->selectsql = "SELECT * FROM innames";
          $this->tablename = "innames";
          $this->key = "ID";
          $this->tabletitle = "Inname";
          $this->setGridActions(array());
          
          $column = new clsColumn();
          $column->setFieldName("MedewerkerID");
          $column->setCaption("Medewerker");
          $column->setReadOnly();
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("ID");
          $column->setCaption("Bonnummer");
          $column->setReadOnly();
          $this->columnheader->addColumn($column);
          
          $column = new clsDateTimeColumn();
          $column->setFieldName("Tijdstip");
          $column->setCaption("Tijdstip ontvangst");   
          $column->setEditType("Date and time");
          $column->setFormControlClass("datetime_control");
          $column->setFormat("d-m-Y H:i");
          $column->setReadOnly();
          $this->columnheader->addColumn($column);                 
     }  
     
     protected function getTotalsHtml()
     {    $output = "<tr>
                          <td>&nbsp;</td>
                     </tr>
                     <tr>
                          <td></td><td class='text-right'>Totaal
                          </td>
                          <td class='text-right' style='border-top:1pt solid black;'>" . $this->getColumnHeader()->findColumn("Vergoeding")->getDisplaySum() . "
                          </td>
                     </tr>";
          return $output;
     }

     public function getPrintHtml()
     {    $innameid = $_GET["inname"];
          $rows = $this->connection->query($this->getSelectSql(" WHERE innames.ID = " . $innameid));
          
          foreach ($rows as $dbrow) 
          {    $row = $this->convertFromTableRow($dbrow);
               break;
          }
          $header = "<table class='table'>
                          <tr>
                               <td colspan='3'>
                                    <h1>Superior Waste - ReMas</h1>
                               </td>
                          </tr> 
                          <tr>
                               <td colspan='3'>
                                    <h2>Uitgiftebon</h2>
                               </td>
                          </tr>";
          
          $column = $this->getColumnHeader()->findColumn("Tijdstip");
          $header .= "<tr><td colspan='3'>" . $column->getDisplayValue($row) . "</td></tr>";
          $column = $this->getColumnHeader()->findColumn("MedewerkerID");
          $header .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $column = $this->getColumnHeader()->findColumn("ID");
          $header .= "<tr><td colspan='3'>" . $column->getCaption() . ": " . $column->getDisplayValue($row) . "</td></tr>";
          $header .= "</table>";
          
          //details
          $this->setSelectSql("SELECT Naam,  
                                        ROUND(Vergoeding,2) as Vergoeding, 
                                        InnameID 
                                   FROM innameapparaat i LEFT JOIN apparaten a
                                                                ON i.ApparaatID = a.ID
                                  WHERE InnameID = " . $innameid . " 
                               ORDER BY Naam");
          
          $this->setColumnHeader(new clsColumnHeader($this->connection));
          $this->setTablename("innames");
          $this->setKey("InnameID");
          $this->setTableTitle("&nbsp;&nbsp;");
          $this->setGridActions(array());
          
          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Naam");
          $this->columnheader->addColumn($column);
          
          $vcolumn = new clsMoneyColumn();
          $vcolumn->setFieldName("Vergoeding");
          $vcolumn->setCaption("Vergoeding");   
          $this->columnheader->addColumn($vcolumn);   
          $rows = $this->connection->query($this->getSelectSql());
          
          return $header . $this->getGridHtml();
     }
}

?>