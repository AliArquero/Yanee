<?php
     require_once(CLASSES_PATH . "table.inc.php");

//[[300]] Begin
class clsWaardeColumn extends clsColumn
{
     public function getFieldValueFromDBFormat($row)
     {    // 30 ==> 011110
          return sprintf("%06s", decbin($row[$this->getFieldName()]));
     } 
     
     public function setFieldValueToDBFormat($bits)
     {    // 001100 ==> 12
          return bindec($bits);
     }    
}
//[[300]] Einde

class clsRol extends clsTableDef
{    
     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, Naam, Omschrijving, Waarde 
                                FROM rollen";
          $this->ordersql = "ORDER BY Naam";
          $this->tablename = "rollen";
          $this->key = "ID";
          $this->tabletitle = "Gebruikers";

          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Naam");
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("Omschrijving");
          $this->columnheader->addColumn($column);
          
          $column = new clsWaardeColumn(); //[[300]]
          $column->setFieldName("Waarde");
          $column->setCaption("Rechten");
          $this->columnheader->addColumn($column);         
     }  
}
?>