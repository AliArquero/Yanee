<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsUitgifteWijzigen extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          $this->selectsql = "SELECT ID, MedewerkerID, OnderdeelID, Tijdstip, GewichtKg, Prijs
                                FROM uitgiftes";
          $this->ordersql = "ORDER BY Tijdstip DESC";
          $this->tablename = "uitgiftes";
          $this->key = "ID";
          $this->tabletitle = "Uitgifte";
          
          $column = new clsLookupColumn();
          $column->setFieldName("MedewerkerID");
          $column->setCaption("Medewerker");
          $column->setLookUpSql("SELECT Naam as lookupresult, ID as lookup_id
                                   FROM medewerkers 
                                  ORDER BY Naam");
          
          $this->columnheader->addColumn($column); 
                                    
          $column = new clsDateTimeColumn();
          $column->setFieldName("Tijdstip");
          $column->setCaption("Tijdstip uitgave");   
          $column->setEditType("Date and time");
          $column->setFormControlClass("datetime_control");
          $format = "d-m-Y H:i";
          $column->setFormat($format);
          $column->setDefaultValue(date($format)); //[[334]]   
          $this->columnheader->addColumn($column); 
          
          $column = new clsLookupColumn();
          $column->setFieldName("OnderdeelID");
          $column->setCaption("Onderdeel");
          $column->setLookUpSql("SELECT Naam as lookupresult, ID as lookup_id
                                   FROM onderdelen 
                                  ORDER BY Naam"); 
          $this->columnheader->addColumn($column); 
                                    
          $column = new clsNumberColumn();
          $column->setFieldName("GewichtKg");
          $column->setCaption("Hoeveelheid (kg)");
          $column->setDecimals(0);
          $this->columnheader->addColumn($column);   
          
          $column = new clsMoneyColumn();
          $column->setFieldName("Prijs");
          $column->setCaption("Ontvangen");
          $this->columnheader->addColumn($column);         
     }
}

class clsUitgifte extends clsUitgifteWijzigen
{
          public function __construct() 
     {
          parent::__construct();
                  
          $column = $this->columnheader->findColumn("Prijs"); 
          $this->columnheader->deleteColumn("Prijs");
          
          $this->gridactions = array();
          $this->savedialogbuttons = array(new clsSaveDialogButton('button_cancel', 'times', 'Annuleren'),
                                           new clsSaveDialogButton('print_uitgifte_bon', 'print', 'Uitgeven en vrachtbrief afdrukken')
                                          );
     }
     
     public function getGridHtml()
     {    return '<div class="invisible ">' . 
                       parent::getGridHtml() . 
                 '</div>' . 
                 '<script src="' . JS_PATH . 'uitgifte.js?ver<%=' . microtime() . '%>"></script>'; //reload custom js on every pageload

     }   
}

?>