<?php
     require_once(CLASSES_PATH . "table.inc.php");
     require_once(CLASSES_PATH . "onderdeelapparaat.inc.php");

class clsApparaatSmall extends clsTableDef
{    
     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, Naam, Omschrijving, Vergoeding 
                                FROM apparaten";
          $this->ordersql = "ORDER BY Naam";
          $this->tablename = "apparaten";
          $this->key = "ID";
          $this->tabletitle = "Apparaten";

          $column = new clsColumn();
          $column->setFieldName("Naam");
          $column->setCaption("Naam");
          $this->columnheader->addColumn($column);
          
          $column = new clsMoneyColumn();
          $column->setFieldName("Vergoeding");
          $column->setCaption("Vergoeding");
          $this->columnheader->addColumn($column);         
     }  
}

class clsApparaatComplete extends clsApparaatSmall
{    
     public function __construct() 
     {
          parent::__construct();
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("Omschrijving");
          $this->columnheader->addColumn($column, "Naam"); 
     } 
     
     protected function getFormControlsHtml()
     {    $columnNaam = $this->getColumnHeader()->findColumn("Naam");
          $columnOmschrijving = $this->getColumnHeader()->findColumn("Omschrijving");
          $columnVergoeding = $this->getColumnHeader()->findColumn("Vergoeding");
          
          return $columnNaam->makeControl(4, true) .
                 $columnOmschrijving->makeControl(6, true) .
                 $columnVergoeding->makeControl(2, true);
     }   
     
     public function getEditHtml()
     {    $oapparaat = new clsOnderdeelApparaat();
          $oapparaat->setGridClass('oapparaat');
          $oapparaat->setGridActions(array(new clsGridAction('button_oapp_new', 'plus'), 
                                            new clsGridAction('button_oapp_edit', 'pencil-square-o', 'disabled'), 
                                            new clsGridAction('button_oapp_delete', 'trash-o', 'disabled')
                                           )
                                     );
          $oapparaat->savedialogbuttons = array(new clsSaveDialogButton('button_oapp_ok', 'check', ''), 
                                                new clsSaveDialogButton('button_oapp_ok', 'close', '')
                                               );
          $oapparaat->setMaster($this, 'ApparaatID');

          $output = '<div class="well well-sm col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                          $this->getFormControlsHtml() . 
                     '</div>';
          $output .= '<div class="row">';
          $output .=      '<div class="oapparaat_grid_container col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                                $oapparaat->getGridHtml() ;
          $output .=           '<div id="oapp_totaal_container" 
                                     class="row oapparaat_grid_container col-xs-10 col-sm-10 col-md-10 col-lg-10">';
          $output .=                '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">' .
                                         $this->makeSaveDialog() .
                                    '</div>
                                     <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                                          Totaal <span id="oapp_totaal" class="align-bottom">.....</span>
                                     </div>
                                </div>
                           </div>';
          $output .=      '<div class="oapparaat_edit_container col-xs-6 col-sm-6 col-md-6 col-lg-6">' .
                                $oapparaat->getEditHtml() .
                          '</div>';
          $output .= '</div>';
          
          $output .=  '<script src="' . JS_PATH . 'apparaat.js?ver<%=' . microtime() . '%>"></script>'; //reload custom js on every pageload
                      
          return $output;
     }
     
     protected function updateDetails()
     {
		$masterid = $_POST["MasterID"];
		if (!$masterid)
		{    $masterid = $this->connection->lastInsertId();
		}
		if (isset($masterid))
          { // Er zijn details    
            // De achtergebleven bestaande details updaten 
               $onderdelen = $_POST['Onderdelen'];
               $onderdelennieuw = $_POST['OnderdelenNieuw'];
               $ids = array();
               if (isset($onderdelen) && ($onderdelen != ""))
               {    $onderdelen = explode(";", $onderdelen);
                    foreach ($onderdelen as $onderdeel)
                    {    $ovelden = explode(",", $onderdeel);
                         $ids[] = $ovelden[0];
                         $sql = "UPDATE onderdeelapparaat
                                    SET OnderdeelID = " . $ovelden[1] . ", 
                                        Percentage = " . $ovelden[2] . "
                                  WHERE ID = " . $ovelden[0];
                         if ($this->connection->query($sql) != true)
                         {    return array("danger", $sql);
                         }
                    }
               }
            // De verwijderde details uit de db verwijderen
               if (count($ids) > 0)
               {    $sql = "DELETE FROM onderdeelapparaat
                             WHERE ApparaatID = " . $masterid . "
                             AND   (ID NOT IN (" . implode(",", $ids) . "))";
                    if ($this->connection->query($sql) != true)
                    {     return array("danger", $sql);
                    }
               }
            
            // De nieuwe details toevoegen
               if (isset($onderdelennieuw) && ($onderdelennieuw != ""))
               {    $onderdelennieuw = explode(";", $onderdelennieuw);
                    foreach ($onderdelennieuw as $onderdeel)
                    {    $sql = "INSERT INTO onderdeelapparaat
                                             (ApparaatID, OnderdeelID, Percentage) 
                                      VALUES (" . $masterid . "," . $onderdeel . ")";  
                         if ($this->connection->query($sql) != true)
                         {
                              return array("danger", $sql);
                         }
                    }
               }
          }
          return array("success");
     }

}

?>