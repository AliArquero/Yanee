<?php
class clsDefaultPage 
{
     protected $datalist;
     
     public function __construct($dlist, $rolcode) 
     {    if (!isset($_SESSION['logged_in_as']))
          {    die("U bent niet ingelogd in ReMaS!");
          }
          $user = $_SESSION['logged_in_as'];

          $this->datalist = $dlist;
     }  
     
     public function defaultHtml()
     {
          return '
               <div id="grid_container" class="col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                    $this->datalist->getGridHtml() . '
               </div>
               <div id="edit_container" class="col-xs-10 col-sm-10 col-md-10 col-lg-10"> ' .
                    $this->datalist->getEditHtml() . '
               </div>';
     }
     
     public function getPrintHtml()
     {    return $this->datalist->getPrintHtml();
     }
     
     public function getHtml()
     {  
          $action = false;		
          if (isset($_POST['row_action'])) 
          {    $action = $_POST['row_action'];
          }
          switch($action) 
          {
               case "save_row":
                    return $this->datalist->getUpdateHtml();
                    break;
               case "insert_row":
                    return $this->datalist->getInsertHtml();
                    break;
               case "delete_row": 
                    return $this->datalist->getDeleteHtml();
                    break;
              default:   
                   return $this->DefaultHtml();        
          }
     }
}
?>