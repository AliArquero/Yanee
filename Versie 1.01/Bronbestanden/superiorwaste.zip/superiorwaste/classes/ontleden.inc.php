<?php
     require_once(CLASSES_PATH . "table.inc.php");
     require_once(CLASSES_PATH . "onderdeelapparaat.inc.php");

class clsOntleden extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT i.ID AS IID, a.ID AS AID, a.Naam AS Apparaat, i.Tijdstip AS Tijd, 
                                     a.GewichtGram AS GewichtGram
                                FROM innameapparaat ia LEFT JOIN apparaten a 
                                                              ON ia.ApparaatID = a.ID
                                                       LEFT JOIN innames i 
                                                              ON i.ID = ia.InnameID "; 
          $this->ordersql = "ORDER BY a.Naam, i.Tijdstip";
          $this->tablename = "innames";
          $this->key = "AID";
          $this->tabletitle = "Ingenomen apparaten";
          $this->gridactions = array(new clsGridAction('button_edit', 'eye', 'disabled'),
                                     new clsGridAction('button_print', 'print'));
          
          $this->savedialogbuttons = array(new clsSaveDialogButton('button_ontleed_ok', 'check', 'Alle onderdelen voor dit apparaat verwerken'), 
                                           new clsSaveDialogButton('button_cancel', 'close', '')
                                          );

          $column = new clsColumn();
          $column->setFieldName("Apparaat");
          $column->setCaption("Apparaat");
          $column->setReadOnly();
          $this->columnheader->addColumn($column);
          
          $column = new clsNumberColumn();
          $column->setFieldName("GewichtGram");
          $column->setCaption("Gewicht");
          $column->setDecimals(0);
          $column->setReadOnly();
          $this->columnheader->addColumn($column);
          
          $column = new clsDateTimeColumn();
          $column->setFieldName("Tijd");
          $column->setCaption("Tijdstip ontvangst");   
          $column->setEditType("Date and time");
          $column->setFormControlClass("datetime_control");
          $column->setFormat("d-m-Y H:i");
          $column->setReadOnly();
          $this->columnheader->addColumn($column);                  
     } 
     
     protected function getFormControlsHtml()
     {    $columnApparaat = $this->getColumnHeader()->findColumn("Apparaat");
          $columnGewichtGram = $this->getColumnHeader()->findColumn("GewichtGram");
          $columnTijd = $this->getColumnHeader()->findColumn("Tijd");
          
          return $columnApparaat->makeControl(4, true) .
                 $columnGewichtGram->makeControl(3, true) .
                 $columnTijd->makeControl(4, true);
     }
     
     public function getEditHtml()
     {    $apparaatspecs = new clsApparaatSpecs();
          $apparaatspecs->setGridClass('apparaatspecs');
          $apparaatspecs->setMaster($this, 'AID');
          $apparaatspecs->gridactions = array(new clsGridAction('apparaatspecs_button_new', 'plus'), 
                                              new clsGridAction('apparaatspecs_button_edit', 'pencil-square-o', 'disabled'), 
                                              new clsGridAction('apparaatspecs_button_delete', 'trash-o', 'disabled') 
                                             );

          $output = '<div class="well well-sm col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                          $this->getFormControlsHtml() . 
                     '</div>';
          $output .= '<div class="row">';
          $output .=      '<div class="grapparaat_grid_container col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                                $apparaatspecs->getGridHtml() . 
                                $this->makeSaveDialog() .
                          '</div>';
          $output .=      '<div class="grapparaat_edit_container col-xs-10 col-sm-10 col-md-10 col-lg-10">' .
                                $apparaatspecs->getEditHtml() . 
                          '</div>';
          $output .= '</div>';
          $output .=  '<script src="' . JS_PATH . 'ontleden.js?ver<%=' . microtime() . '%>"></script>'; //reload custom js on every pageload
                      
          return $output;
     }
     
     private function sqlError($sql)
     {    return $this->sqlResult("danger", $sql . "<br>is mislukt.<br>De onderdelen van dit apparaat zijn NIET verwerkt."); 
     }
     
     public function getUpdateHtml()
     {    $innameID = $_POST["innameID"];
          $apparaatid = $_POST["apparaatID"];
          $gewichten = json_decode($_POST["gewichten"], true);
          foreach($gewichten as $key=>$gewicht)
          {    $sql = "UPDATE onderdelen 
                          SET VoorraadKg = ((1000 * VoorraadKg) + " . $gewicht . ") / 1000
                        WHERE ID = " . $key . "; ";
               if (!($this->connection->query($sql) == true))
               {    return $this->sqlError($sql); 
               }
          }
          $sql = "UPDATE innameapparaat 
                     SET Ontleed = 1 
                   WHERE InnameID = " . $innameID . " AND ApparaatID = " . $apparaatid . "; ";
          if ($this->connection->query($sql) == true)
          {    return $this->sqlResult("success", "De onderdelen van dit apparaat zijn verwerkt.");
		} 
		else 
		{    return $this->sqlError($sql); 
		}							
     }
}

?>