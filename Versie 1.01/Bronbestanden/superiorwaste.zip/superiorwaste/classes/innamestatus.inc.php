<?php
     require_once(CLASSES_PATH . "table.inc.php");

class clsStatus extends clsTableDef
{    
     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT ID, Code, Omschrijving
                                FROM innamestatus";
          $this->ordersql = "ORDER BY Code";
          $this->tablename = "innamestatus";
          $this->key = "ID";
          $this->tabletitle = "Innamestatus";

          $column = new clsColumn();
          $column->setFieldName("Code");
          $column->setCaption("Code");
          $this->columnheader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("Omschrijving");
          $column->setCaption("Omschrijving");
          $this->columnheader->addColumn($column);
     }  
}
?>