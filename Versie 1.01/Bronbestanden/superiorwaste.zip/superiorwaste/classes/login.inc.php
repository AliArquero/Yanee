<?php

class clsLogin
{
     protected $connection;
    
     public function __construct() 
     {
          require_once(CONFIG_PATH . "database.inc.php");
          $this->connection = database::connect();
     } 
     
     private function loginResult($status, $tekst)
     {    //$status afgeleid van bootstrap Alerts 
          $output = '
               <div id="status_result_code">' . $status . '</div>     
               <div id="status_result_msg">' . $tekst . '</div>';     // Moet op 1 regel staan !
          return $output;
     }
     
     public function getHtml()
     {    $password = $_POST["pword"]; 
          $sql = "SELECT m.ID AS mID, m.RolID AS mRolID, m.Naam AS mNaam, 
                         m.Wachtwoord AS mWachtwoord, m.Emailadres  AS mEmailadres, 
                         r.ID AS rID, r.Naam AS rNaam, 
                         r.Omschrijving AS rOmschrijving, r.Waarde AS rWaarde  
                    FROM medewerkers m
                  LEFT JOIN rollen r ON m.RolID = r.ID 
                   WHERE m.Naam = '" . $_POST["uname"] . "'
                     AND m.Wachtwoord = '" . $password . "'"; 
          $rows = $this->connection->query($sql);
          if (!$rows || ($rows->rowCount() != 1))
          {    return $this->loginResult("danger", "Het inloggen is mislukt!");
          };
          
          foreach ($rows as $row) 
          {    $result = $row;
               break;
          }
          
          // Welke schermen mag deze rol gebruiken?
          // De namen van de schermen, en de menu_knoppen, zoals inname.inc.php en menu_knop_inname
          // De volgorde is die van het bitpatroon in de tabel rollen, het veld Waarde 
          // Deze volgorde moet overeenkomen met de plaats van het scherm in het bitpatroon.
          
          $schermen = array("inname","verwerking","uitgifte","rapportage","onderhoud","gebruikers");
          $bit = sprintf("%06s", decbin($result["rWaarde"]));
          $toegestaan = array();
          for ($i = 0; $i < 6; $i++)
          {
               if (substr($bit, $i, 1) == "1")
               {    $toegestaan[] = $schermen[$i];
               }
          }
          $result["schermen"] = join("," , $toegestaan);
          
          $_SESSION['logged_in_as'] = $result;
          
          return $this->loginResult("success", json_encode($result));
     } 
}
?>