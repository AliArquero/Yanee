<?php

class clsColumnHeader
{
     private $columns;
     private $connection;
     
     public function __construct($connection) 
     {
          $this->columns = array();
          $this->connection = $connection;
     } 
     
     public function addColumn($column, $afterColumnName = false)
     {
          $column->setLookupValues($this->connection);
          if ($afterColumnName)
          {
               $newcolumns = array();
               foreach ($this->columns as $col)
               {    $newcolumns[] = $col;
                    if ($col->getCaption() == $afterColumnName)
                    {    $newcolumns[] = $column;
                    }
               }
               $this->columns = $newcolumns;
          }                 
          else
          {    $this->columns[] = $column;
          }
     }    
    
     public function getColumns()
     {    return $this->columns;
     }
     
     public function findColumn($name)
     {    foreach ($this->getColumns() as $column)
          {    if ($column->getFieldName() == $name)
               {    return $column;
               }
          }
          return false;
     }
     
     public function deleteColumn($name)
     {    $newcolumns = array();
          foreach ($this->getColumns() as $column)
          {    if ($column->getFieldName() != $name)
               {    $newcolumns[] = $column;
               }
          }
          $this->columns = $newcolumns;
     }
     
     public function deleteAllColumns()
     {    $this->columns = array();
     }
     
     public function replaceColumn($name, $newcolumn)
     {    $newcolumns = array();
          foreach ($this->getColumns() as $column)
          {    if ($column->getFieldName() == $name)
               {    $newcolumn->setLookupValues($this->connection);
                    $newcolumns[] = $newcolumn;
               }
               else
               {    $newcolumns[] = $column;
               }
          }
          $this->columns = $newcolumns;
     }
}

class clsColumn
{
     private $fieldName;
     private $fieldCaption;
     private $edittype; /* Bootstrap input types: Text, Search, Email, URL, Telephone
                                                  Password, Number, Date and time, 
                                                  Date, Month, Week, Time*/
     private $readonly;
     private $format;
     private $columnheaderclass;
     private $defaultvalue;
     private $formcontrolclass;
     private $printcolumnwidth; // width in bootstrap column width (1..12)
     
     public function __construct() 
     {
          $this->edittype = "Text";
          $this->readonly = false;
          $this->format = "";
          $this->columnheaderclass = "";
          $this->defaultvalue = "";
          $this->formcontrolclass = "";
          $this->printcolumnwidth = false;
     } 
     
     public function getDefaultValue()
     {
          return $this->defaultvalue;
     }
     
     public function setDefaultValue($defaultvalue)
     {
          $this->defaultvalue = $defaultvalue;
     }
     
     public function getCaption()
     {
          return $this->fieldCaption;
     }
     
     public function setCaption($caption)
     {
          $this->fieldCaption = $caption;
     }
     
     public function getFieldName()
     {
          return $this->fieldName;
     }
     public function setFieldName($fieldname)
     {
          $this->fieldName = $fieldname;
     }
     
     public function getEditType()
     {
          return $this->edittype;
     }
     
     public function setEditType($edittype)
     {
          $this->edittype = $edittype;
     }
     
     public function setLookupValues($connection)
     {
          return; //Overridden in Lookup columns
     }
     
     public function getReadOnly()
     {
          return $this->readonly;
     }
     
     public function setReadOnly()
     {
          $this->readonly = true;
     }
     
     public function getFormat()
     {
          return $this->format;
     }
     
     public function setFormat($value)
     {
          $this->format = $value;
     }  
     
     public function getColumnHeaderClass()
     {
          return $this->columnheaderclass;
     }
     
     public function setColumnHeaderClass($value)
     {
          $this->columnheaderclass = "class='" . $value . "'";
     }  
     
     public function getPrintColumnWidth()
     {
          return $this->printcolumnwidth;
     }
     
     public function setPrintColumnWidth($value)
     {
          $this->printcolumnwidth = $value;
     }  
     
     public function getFieldValueFromDBFormat($row)
     {
          return $row[$this->getFieldName()];
     }
     
     public function setFieldValueToDBFormat($value)
     {
          return $value;
     }
     
     public function getFormControlClass()
     {    $fcclass = $this->formcontrolclass;
          if ($fcclass != "")
          {    $fcclass .= " ";
          }
          return $fcclass;
     }
     
     public function setFormControlClass($class)
     {
          $this->formcontrolclass = $class;
     }
     
     public function getFieldValue($row)
     {
          return $row[$this->getFieldName()];
     }
     
     public function getDisplayValue($row)
     {
          return $this->getFieldValue($row);
     }
     
     public function resetSum()
     {    return;
     }
     
     public function getDisplaySum()
     {    return "";
     }
     
     public function getSum()
     {     return "";
     }
     
     public function makeFormControlSet()
     { // Alleen formcontrols, geen data   
          $fieldname = $this->getFieldName();
          $name = $fieldname . "_id";
          $fieldcaption = $this->getCaption();
          
          $output = 
              "<div class='form-group'>
                    <label for='" . $name . "'>" . $fieldcaption . "
                    </label>";
          
          $output .= $this->makeInput($name);
          $output .= 
              "</div>";

          return $output;
     }
     
     public function makeInput($name)
     {    $readonly = " readonly='readonly'";
          $readonlyclass = " form-control-plaintext";
          if (!$this->getReadOnly())
          {    $readonly = "";
               $readonlyclass = "";                  
          }
          $output = "<input type='" . $this->getEditType() . "' 
                            class='form-control$readonlyclass' 
                            $readonly 
                            id='" . $name . "'  
                            name='" . $name . "'";
          if ($this->getDefaultValue())
          {    $output .= " defaultvalue='" . $this->getDefaultValue() . "'";
          }
          $output .= 
                    ">";
          return $output;
     } 
     
     public function getTableCellHtml($row, $keyname)
     {    $fldname = $this->getFieldName();
          
          return
               "<td id='td_" . $fldname . "_" . $row[$keyname] . "'
                    display_value='" . $this->getDisplayValue($row) . "'>" .
                     $this->getDisplayValue($row) . 
               "</td>";
     }
     
     protected function vulAan($str, $lengte)
     {    $meer = max($lengte - strlen($str), 0);
          return str_repeat("&nbsp;", $meer) . $str;
     }
     
     public function makeControl($width, $label = false)
     {    $fieldname = $this->getFieldName();
          $name = $fieldname . "_id";
          $output = '<div class="col-xs-' . $width . ' 
                                 col-sm-' . $width . ' 
                                 col-md-' . $width . ' 
                                 col-lg-' . $width . '">';
          if ($label)
          {    $output .= $this->getCaption();
          }
          $output .= $this->makeInput($name) .
                    '</div>';
          return $output;
     }
}

class clsDateTimeColumn extends clsColumn
{
     public function __construct() 
     {
          parent::__construct();
          $this->formcontrolclass = "datetime_control";
     }
     
     public function getFieldValueFromDBFormat($row)
     {    $datum = $row[$this->getFieldName()];
          if (!$datum)
               return null;
          
          // 2017-02-15 12:34:15 to 15-02-2017 12:34:15
          return date_format(date_create($datum), $this->getFormat());
     } 
     
     public function setFieldValueToDBFormat($datumtijd)
     {    if ((!$datumtijd) || ($datumtijd === ""))
          {    return "NULL";
          }
          // 15-02-2017 12:34:15 to 2017-02-15 12:34:15
          $dtarray = explode(" ", trim($datumtijd));
          $datum = explode("-", $dtarray[0]);
          $tijd = explode(":", $dtarray[1]);
          return sprintf("%04d-%02d-%02d %02d:%02d:%02d", 
                         $datum[2], $datum[1], $datum[0], $tijd[0], $tijd[1], $tijd[2]);
     } 
     
     public function makeInput($name) // Overrides clsColumn->makeInput()
     {    $readonly = " readonly='readonly'";
          $disabled = "disabled='true' "; 
          $readonlyclass = " form-control-plaintext";
          if (!$this->getReadOnly())
          {    $readonly = "";
               $readonlyclass = ""; 
               $disabled = ""; 
          }
          return "<input $disabled
                         type='" . $this->getEditType() . "' 
                         class='" . $this->getFormControlClass() . "form-control$readonlyclass' 
                         $readonly 
                         id='" . $name . "'  
                         name='" . $name . "'>";
     }
}

class clsLookupColumn extends clsColumn
{
     private $lookupsql;
     private $nulloption;
     
     public function __construct() 
     {
          parent::__construct();
          $this->edittype = "Select";
          $this->lookupsql = "";
          $this->formcontrolclass = "selectpicker";
          $this->nulloption = false;
     } 
     
     public function getLookUpSql()
     {
          return $this->lookupsql;
     }
     
     public function setLookupSql($sql)
     {
          $this->lookupsql = $sql;
     }
     
     public function getNullOption()
     {
          return $this->nulloption;
     }
     
     public function setNullOption($option)
     {
          $this->nulloption = $option;
     }
     
     public function getLookUpValues()
     {
          return $this->lookupvalues;
     }
     
     public function setLookupValues($connection)
     {
          $result = array();
          foreach($connection->query($this->getLookUpSql()) as $row) 
          { 
               $result[$row['lookup_id']] = $row['lookupresult'];
          }
          $this->lookupvalues = $result;
     }
     
     public function getDisplayValue($row)
     {    $lookupvals = $this->getLookUpValues();
          return $lookupvals[$row[$this->getFieldName()]];
     }
     
     public function makeInput($name)// Overrides clsColumn->makeInput()
     {    $readonly = " readonly='readonly'";
          $readonlyclass = " form-control-plaintext";
          $disabled = "disabled='true' "; 
          if (!$this->getReadOnly())
          {    $readonly = "";
               $readonlyclass = ""; 
               $disabled = ""; 
          }
          $output =  
               "<select $disabled class='" . $this->getFormControlClass() . "form-control$readonlyclass' 
                        $readonly 
                        id='" . $name . "'  
                        name='" . $name . "'>";
          if ($this->getNullOption())
          {    $output .= "
                     <option value=''>";
               $output .= 
                     $this->getNullOption() . "</option>";
          }
          foreach($this->getLookUpValues() as $id => $result) 
          {    $output .= "
                     <option value='" . $id . "'>";
               $output .= 
                     $result . "</option>";
          }
          $output .= 
               "</select>";
          return $output;
     }
}
     
class clsNumberColumn extends clsColumn
{    private $sum;
     private $decimals;
     
     public function __construct() 
     {
          parent::__construct();
          $this->sum = 0;
          $this->decimals = 2;
          $this->setColumnHeaderClass("text-right");
     } 
    
     public function getDisplaySum()
     {    return $this->vulAan(number_format($this->getSum(), $this->getDecimals(), ',', '.'), 10);
     }
     
     public function resetSum()
     {     $this->sum = 0;
     }
     
     public function getSum()
     {     return $this->sum;
     }
     
     public function addSum($value)
     {     $this->sum += $value;
     }
     
     public function getDecimals()
     {     return $this->decimals;
     }
     
     public function setDecimals($decimals)
     {     $this->decimals = $decimals;
     }
     
     public function getTableCellHtml($row, $keyname)
     {    $this->addSum(floatval($this->getFieldValue($row)));
          $fldname = $this->getFieldName();
          return
               "<td id='td_" . $fldname . "_" . $row[$keyname] . "' " .
                    $this->getColumnHeaderClass() . "' 
                    display_value='" . $this->getDisplayValue($row) . "'>" .
                     $this->vulAan(number_format($this->getDisplayValue($row), $this->getDecimals(), ',', '.'), 10) . 
               "</td>";
     }
}
class clsMoneyColumn extends clsNumberColumn
{    public function __construct() 
     {
          parent::__construct();
     } 
    
     public function getDisplaySum()
     {    return "&euro;" . $this->vulAan(number_format($this->getSum(), $this->getDecimals(), ',', '.'), 10);
     }
     
     public function getTableCellHtml($row, $keyname)
     {    $this->addSum(floatval($this->getFieldValue($row)));
          $fldname = $this->getFieldName();
          return
               "<td id='td_" . $fldname . "_" . $row[$keyname] . "'
                    class='text-right' 
                    display_value='" . $this->getDisplayValue($row) . "'>
                     &euro;" .
                     $this->vulAan(number_format($this->getDisplayValue($row), $this->getDecimals(), ',', '.'), 10) . 
               "</td>";
     }
}

class clsLookupMoneyColumn extends clsLookupColumn
{    public function getTableCellHtml($row, $keyname)
     {    $fldname = $this->getFieldName();
          return
               "<td id='td_" . $fldname . "_" . $row[$keyname] . "'
                    class='text-right' 
                    display_value='" . $this->getDisplayValue($row) . "'>
                     &euro;" .
                     $this->vulAan(number_format($this->getDisplayValue($row), 2, ',', '.'), 10) . 
               "</td>";
     }
}

class clsTextColumn extends clsColumn
{    public function makeInput($name)// Overrides clsColumn->makeInput()
     {    $readonly = " readonly='readonly'";
          $readonlyclass = " form-control-plaintext";
          $disabled = "disabled='true' "; 
          if (!$this->getReadOnly())
          {    $readonly = "";
               $readonlyclass = ""; 
               $disabled = ""; 
          }
          $output =  
               "<textarea $disabled class='form-control$readonlyclass' 
                        $readonly 
                        id='" . $name . "'  
                        rows='5' 
                        name='" . $name . "'>
                </textarea>";
          return $output;
     }

}

class clsGridAction
{
     protected $actionid;
     protected $icon;
     protected $extraclass;
     
     public function __construct($actionid, $icon, $extraclass = "") 
     {    $this->actionid = $actionid;
          $this->icon = $icon;
          $this->extraclass = $extraclass;
     }
     
     public function getActionID()
     {    return $this->actionid;
     }
     
     public function getIcon()
     {    return $this->icon;
     }
     
     public function getExtraClass()
     {    return $this->extraclass;
     }
     
     public function setActionID($value)
     {    $this->actionid = $value;
     }
     
     public function setIcon($value)
     {    $this->icon = $value;
     }
     
     public function setExtraClass($value)
     {    $this->extraclass = $value;
     }
}

class clsSaveDialogButton
{
     protected $buttonid;
     protected $buttonicon;
     protected $buttontext;
     
     public function __construct($buttonid,$buttonicon, $buttontext) 
     {    $this->buttonid = $buttonid;
          $this->buttonicon = $buttonicon;
          $this->buttontext = $buttontext;
     }
     
     public function getButtonID()
     {    return $this->buttonid;
     }
     
     public function getButtonIcon()
     {    return $this->buttonicon;
     }
     
     public function getButtonText()
     {    return $this->buttontext;
     }
     
     public function setButtonID($value)
     {    $this->buttonid = $value;
     }
     
     public function setButtonIcon($value)
     {    $this->buttonicon = $value;
     }
     
     public function setButtonText($value)
     {    $this->buttontext = $value;
     }
}

class clsTableDef
{
     protected $connection;
     protected $columnheader;
     protected $body;
     protected $tablename;
     protected $selectsql;
     protected $ordersql;
     protected $key;
     protected $keyvalue;
     protected $soort;
     protected $readonly;
     protected $lastmessage; 
     protected $tabletitle;
     protected $gridactions;
     protected $gridclass;
     protected $master;
     protected $masterfieldname;
     protected $savedialogbuttons;
        
     public function __construct() 
     {
          require_once(CONFIG_PATH . "database.inc.php");
          $this->connection = database::connect();
          $this->columnheader = new clsColumnHeader($this->connection);
          $this->lastmessage = ""; 
          $this->keyvalue = -1;
          $this->key = false;
          $this->tabletitle = "";
          $this->selectsql = "";
          $this->ordersql = "";
          $this->readonly = false;
          $this->detailskeuzegrid = false;
          $this->gridactions = array(new clsGridAction('button_new', 'plus'), 
                                     new clsGridAction('button_edit', 'pencil-square-o', 'disabled'), 
                                     new clsGridAction('button_delete', 'trash-o', 'disabled'), 
                                     new clsGridAction('button_print', 'print') //[[310]]
                                    );
          $this->savedialogbuttons = array(new clsSaveDialogButton('button_save', '', 'Bewaren'), 
                                           new clsSaveDialogButton('button_cancel', '', 'Annuleren')
                                          );
          $this->gridclass = 'table';
          $this->master = false;
          $this->masterfieldname = false;
     } 
     
     public function getColumnHeader()
     {
          return $this->columnheader;
     }  
     
     public function setColumnHeader($columnheader)
     {
          $this->columnheader = $columnheader;
     }  
     
     public function getSelectSql($where = "")
     {    return $this->selectsql . " " . $where . " " . $this->ordersql;
     } 
     
     public function setSelectSql($sql)
     {    $this->selectsql = $sql;
     } 
     
     public function setKey($key)
     {
          $this->key = $key;
     } 

     public function getKey()
     {
          return $this->key;
     } 

     public function getKeyValue()
     {
          return $this->keyvalue;
     } 

     public function setKeyValue($value)
     {
          $this->keyvalue = $value;
     } 

     public function setTableName($tablename)
     {
          $this->tablename = $tablename;
     } 

     public function getTableName()
     {
          return $this->tablename;
     } 

     public function setSoort($soort)
     {
          $this->soort = $soort;
     } 
     
     public function setReadOnly()
     {
          $this->readonly = true;
     } 
         
     public function getReadOnly()
     {
          return $this->readonly;
     } 
         
     protected function setLastMessage($value)
     {
          $this->lastmessage = $value;
     }
     
     protected function getLastMessage()
     {
          return $this->lastmessage;
     }
     
     public function setTableTitle($value)
     {
          $this->tabletitle = $value;
     }
     
     public function getTabletitle()
     {
          return $this->tabletitle;
     }
         
     public function setGridActions($value)
     {
          $this->gridactions = $value;
     }
     
     public function getGridActions()
     {
          return $this->gridactions;
     }
         
     public function setSaveDialogButtons($value)
     {
          $this->savedialogbuttons = $value;
     }
     
     public function getSaveDialogButtons()
     {
          return $this->savedialogbuttons;
     }
         
     public function setGridClass($value)
     {
          $this->gridclass = $value;
     }
     
     public function getGridClass()
     {
          return $this->gridclass;
     }
         
     public function setMaster($master, $masterfieldname)
     {
          $this->master = $master;
          $this->masterfieldname = $masterfieldname;
     }
     
     public function getMaster()
     {
          return $this->master;
     }
         
     public function getMasterFieldName()
     {
          return $this->masterfieldname;
     }
     
     protected function getTotalsHtml()
     {    return "";
     }
         
     public function getWidthClass()
     {    $colw = 0;
          $widthclass = " class='col-xs-* col-sm-* col-md-* col-lg-*'";
          foreach ($this->getColumnHeader()->getColumns() as $column)
          {    if ($column->getPrintColumnWidth())
               {    $colw += $column->getPrintColumnWidth();
               }
               else
               {    return "";
               }
          }
          
          if ($colw > 0)
          {    return str_replace("*", $colw, $widthclass);
          }
          return "";
     }
         
     public function makeSaveDialog()
     {    $output = "<div class='row'>
                          <div class='help-block'>
                          </div>
                          <div class='centered'>";
          $buttons = $this->getSaveDialogButtons();
          $btnsout = array();
          
          foreach ($buttons as $button)
          {    $bspace = "&nbsp;";
               if (($button->getButtonIcon() == "") || ($button->getButtonText() == "")) 
               {    $bspace = "";
               }
               
               $btnsout[] = "<button class='btn btn-success' id='" . $button->getButtonID() . "'>
                                  <span class='fa fa-" . $button->getButtonIcon() . "'>" . $bspace . $button->getButtonText() . "
                                  </span>
                             </button>";
          }
          
          $output .= implode("&nbsp;", $btnsout) . 
                         "</div>
                     </div>";
          return $output;
     }
    
     private function noKeyValue()
     {    $this->keyvalue = -1;		
          if (isset($_POST['row_key_value'])) 
          {    $this->keyvalue = $_POST['row_key_value'];
          }
          return ($this->keyvalue < 0);
     }
     
     protected function sqlResult($status, $tekst, $newrowdata = false)
     {    //$status afgeleid van bootstrap Alerts 
          $output = '
               <div id="status_result_code">' . $status . '</div>     
               <div id="status_result_msg">' . $tekst . '</div>';     // Moet op 1 regel staan !
          if ($newrowdata)
          {    $output .= '<table id="status_new_row">' . $newrowdata . '</table>';
          };
          return $output;
     }
     
     protected function getFormControlsHtml()
     {    $output = "";
          foreach ($this->getColumnHeader()->getColumns() as $column)
          {    $output .= $column->makeFormControlSet();
          }
          return $output;
     }
     
     public function getEditHtml()
     {
          $output = $this->getFormControlsHtml() .
                    $this->makeSaveDialog();
          return $output;
     }
     
     protected function updateDetails()
     {    return array("success");
     }
         
     public function getUpdateHtml()
     {    if ($this->noKeyValue())
          {    return $this->sqlResult("danger", "Onbekende gegevens."); 
          }
          $values = array();
          $fldnames = array();
          foreach ($this->getColumnHeader()->getColumns() as $column)
          {    $val = $column->setFieldValueToDBFormat($_POST[$column->getFieldName()]);
               if ($val != "NULL")
               {    $val = "'" . $val . "'";
               }
               $values[$column->getFieldName()] = $val;
               $fldnames[] = $column->getFieldName();
          }
          
          if (!$this->checkBeforeSave($values))
          {    return $this->sqlResult("warning", $this->getLastMessage()); 
          }
          
          
          $sql = "UPDATE " . $this->getTableName() . " SET ";
          // Submitted key-value pairs
          $fvpairs = array();
          foreach ($values as $field => $value)
          {    $fvpairs[] = $field . " = " . $value;
          }
          $where = "   WHERE " . $this->getKey() . " = '" . $this->getKeyValue() . "'";
          $sql .= join(', ', $fvpairs) . $where; // Convert key-value pairs to comma separated string
          $sqlok = false;
          if ($this->connection->query($sql) == true)
          {    // get updated row
               $tablerowsnew = $this->connection->query($this->getSelectSql($where));
               if (!$tablerowsnew)
               {    return $this->sqlResult("warning", "De gegevens zijn opgeslagen, maar niet teruggevonden");
               };
               foreach ($tablerowsnew as $row) 
               {    $output = $this->getRowHtml($row);
                    break;
               }
               $sqlok = true;
		}
		
		if ($sqlok)
		{    $detailresult = $this->updateDetails();
	          if ($detailresult[0] != "success")
	          {    return $this->sqlResult($detailresult[0], $detailresult[1]);
	          }
		     return $this->sqlResult("success", "De gegevens zijn opgeslagen.", $output);
		}
		else 
		{    return $this->sqlResult("danger", $sql . " is mislukt. De gegevens zijn NIET opgeslagen"); 
		}
		
     }
     
     public function getInsertHtml()
     {
          // Submitted fields and values
          $fldnames = array();
          $values = array();
          foreach ($this->getColumnHeader()->getColumns() as $column)
          {
               $fldnames[] = $column->getFieldName();
               $values[] = $column->setFieldValueToDBFormat($_POST[$column->getFieldName()]);
          }
          $checkvalues = array();
          foreach ($values as $i => $value)
          {
               $checkvalues[$fldnames[$i]] =  $value;
          }
          if (!$this->checkBeforeSave($checkvalues))
          {
               return $this->sqlResult("warning", $this->getLastMessage()); 
          } 
          
          $sql = 
               "INSERT INTO " . $this->getTableName() . 
                          " (" . join(', ', $fldnames) . ") 
                     VALUES ('" . join("', '", $values) . "')";  
                     
          if ($this->connection->query($sql) == true)
          {    // get inserted row
               $sqlnew = "SELECT * " .
                         "  FROM " . $this->getTableName() . 
                         " WHERE " . $this->getKey() . " = LAST_INSERT_ID()";
                         
               $tablerowsnew = $this->connection->query($sqlnew);
               if (!$tablerowsnew || ($tablerowsnew->rowCount() < 1))
               {    return $this->sqlResult("warning", $sqlnew . "De gegevens zijn toegevoegd, maar niet teruggevonden");
               };
               
               foreach ($tablerowsnew as $row) 
               {    $output = $this->getRowHtml($row);
                    break;
               }
               $detailresult = $this->updateDetails();
	          if ($detailresult[0] != "success")
	          {    return $this->sqlResult($detailresult[0], $detailresult[1]);
	          }
               return $this->sqlResult("success", "De gegevens zijn toegevoegd.", $output);
		} 
		else 
		{    return $this->sqlResult("danger", $sql . " is mislukt. De gegevens zijn NIET toegevoegd"); 
		}							
    }
     
     public function getDeleteHtml()
     {    if ($this->noKeyValue())
          {
               return $this->sqlResult("warning", "Onbekende gegevens.");
          }
          
          if (!$this->checkBeforeDelete())
          {
               return $this->sqlResult("warning", $this->getLastMessage());
          }
          
          $sql =  "DELETE FROM " . $this->getTableName();
          $sql .= " WHERE " . $this->getKey() . " = '" . $this->getKeyValue() . "'";

          if ($this->connection->query($sql) == true)
          {    return $this->sqlResult("success", "De gegevens zijn verwijderd.");
		} 
		else 
		{    return $this->sqlResult("danger", $sql . "<br>is mislukt.<br>De gegevens zijn NIET verwijderd"); 
		     die;
		}							
     }
     
     protected function checkBeforeDelete() 
     {
          $this->lastmessage = "";
          return true;
     }
     
     protected function checkBeforeSave($values) 
     {
          $this->lastmessage = "";
          return true;
     }
     
     protected function convertFromTableRow($row)
     {    foreach ($this->getColumnHeader()->getColumns() as $column)
          {
               $fldname = $column->getFieldName();
               $row[$fldname] = $column->getFieldValueFromDBFormat($row);
          }
          return $row;
     }

     private function convertToTableRow($postedvalues)
     {    foreach ($this->getColumnHeader()->getColumns() as $column)
          {
               $fldname = $column->getFieldName();
               $row[$fldname] = $column->getFieldValueFromDBFormat($row);
          }
          return $row;
     }
     
     protected function getTableRowsHtml($row)
     {    $output = "";
          foreach ($this->getColumnHeader()->getColumns() as $column)
          {    $output .= $column->getTableCellHtml($row, $this->getKey());
          }
          return $output;
     }
     
     protected function getRowHtml($tablerow)
     {    $row = $this->convertFromTableRow($tablerow);
          $output = "<tr class='" . $this->getGridClass() . "_row'  
                         row_key_value='" . $row[$this->getKey()] . "'
                         row_data='" . json_encode($row) . "'>" .
                          $this->getTableRowsHtml($row) .
                    "</tr>";
          return $output;
     }
     
     private function getActionButtonsHtml($numcols)
     {    $output = " <th colspan='" . $numcols .  "' class='text-right'>";
          $gridactions = $this->getGridActions();
          foreach ($gridactions as $action)
          {    $output .= "<button type='button' 
                                   class='btn btn-success " . $this->getGridClass() . "_action_button " . $action->getExtraClass() . "' 
                                   id='" . $action->getActionID() . "'>
                                <span class='fa fa-" . $action->getIcon() . "'></span>
                           </button>&nbsp;";
          }; 
          $output .= "</th>";
          return $output;
     }

     
     public function getGridHtml()
     {    $tablerows = $this->connection->query($this->getSelectSql());
          $tablecolumns = $this->getColumnHeader()->getColumns();
          $fieldnames = array();
          foreach ($tablecolumns as $column)
          {    $fname = $column->getFieldName();
               $default = $column->getDefaultValue();
               $fieldnames[$fname] = $default;
          }
          $numcols = count($tablecolumns);
          $output = 
              "<table class='table table-sm'
                      id='" . $this->getGridClass() . "_grid'  
                      table_columns='" . json_encode($fieldnames) . "' 
                      table_title='" . $this->getTableTitle() . "'";
                      
          if ($this->getMaster())
          {    $output .=   "masterclass='" . $this->getMaster()->getGridClass() . "' " .
                            "masterfieldname='" . $this->getMasterFieldName() . "' ";
          }
          
          $titlespan = round($numcols / 2);
          $actionspan = $numcols - $titlespan;
          $output .= 
              ">
                    <colgroup>";
          $colclass = " class='col-xs-* col-sm-* col-md-* col-lg-*'";
          foreach ($tablecolumns as $column)
          {    $colw = "";
               if ($column->getPrintColumnWidth())
               {    $colw = str_replace("*", $column->getPrintColumnWidth(), $colclass);
               }
               $output .=    "<col" . $colw . ">";
          }
          $output .= 
                   "</colgroup>
                    <thead>
                         <tr>
                              <th colspan='" . $titlespan .  "' class='text-left'>" . $this->getTableTitle() . "
                              </th>" .
                                   $this->getActionButtonsHtml($actionspan) .
                        "</tr>
                         <tr>";
          foreach ($tablecolumns as $column)
          {    $column->resetSum();
               $output .=    "<th " . $column->getColumnHeaderClass() . ">" . 
                                  $column->getCaption() . 
                             "</th>";
          }
          
          $output .= "   </tr>
                    </thead>
                    <tbody>";
          if ($tablerows)
          {
               foreach ($tablerows as $row) 
               {    $output .= $this->getRowHtml($row);
               }
          }
          $output .= $this->getTotalsHtml();
          $output .= "
                    </tbody>
               </table>"; 
          return $output;
     }    
}
?>