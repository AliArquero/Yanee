<?php
     echo '
          <h4>Welkom bij ReMaS,<br><br>het REcycle MAnagement System voor het project<br><br>Superior Waste van de gemeente Emst.</h4></br></br>
          <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4"">
               <input type="text" id="userName" class="form-control input-sm chat-input" placeholder="Gebruikersnaam" /></br>
               <input type="password" id="userPassword" class="form-control input-sm chat-input" placeholder="Wachtwoord" /></br>
               <a id="button_login" href="#" class="btn btn-success btn-md">Inloggen <i class="fa fa-sign-in"></i></a>
          </div>';
?>