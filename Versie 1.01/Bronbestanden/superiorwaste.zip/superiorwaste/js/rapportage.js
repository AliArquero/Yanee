function CustomInitDocument() 
{    $("#button_rapport_print").on("click", function() 
                                            {    $('#rapport_form').submit();
                                                 LoadMainContainer(currentURL); 
                                            }
                                  )
} 



