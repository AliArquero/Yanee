function CustomInitDocument() 
{    $(".apparaat_row").on("click", ApparaatRowClick);
               
     $(".ingenomen_row").on("click", IngenomenRowClick);   
     
     $("#button_inname").on("click", function(event) 
                                     {    if (RowSelected("selected_apparaat"))
                                               NeemIn();
                                     }
                           );
     $("#button_remove").on("click", function(event) 
                                     {    if (RowSelected("selected_ingenomen"))
                                          {    var row = $(".selected_ingenomen_row");
                                               NeemTerug(row);
                                          }
                                     }
                           );
     
     $("#button_remove_all").on("click", function(event) 
                                         {    ShowDialog("warning", "Alle apparaten terugnemen?", null, NeemAllesTerug, DoeNiks)
                                         }
                               );
     $("#print_inname_bon").on("click", PrintBon);
} 

function AfterShownDetails()
{ // Override van function.js --> AfterShownDetails()
     TotaalEnKnoppen();
}

function ApparaatRowClick() 
{    $(".apparaat_row").removeClass("bg-success selected_apparaat_row");
     $(this).addClass("bg-success selected_apparaat_row");
     $(".apparaat_action_button").removeClass("disabled");
}

function IngenomenRowClick() 
{    $(".ingenomen_row").removeClass("bg-success selected_ingenomen_row");
     $(this).addClass("bg-success selected_ingenomen_row");
     $(".ingenomen_action_button").removeClass("disabled");
}

function NeemIn()
{    var huidigerow = $(".selected_apparaat_row");
     huidigerow.removeClass("bg-success selected_apparaat_row");
     huidigekey = huidigerow.attr('row_key_value');
     var nieuwerow = huidigerow.clone(true, true); 
     nieuwerow.removeClass("apparaat_row");
     nieuwerow.addClass("ingenomen_row");
     nieuwerow.addClass("row_is_active");
     var nieuwerowkeyval = 0;
     $.each($('.ingenomen_row.row_is_active'), function(index, row)
                                               {    var keyvalue = $(this).attr('row_key_value');
                                                    if (parseInt(keyvalue) < nieuwerowkeyval)
                                                    {    nieuwerowkeyval = keyvalue;
                                                    }
                                               }
           );
     nieuwerowkeyval--;
     nieuwerow.attr('row_key_value', nieuwerowkeyval);
     var rowhtml = nieuwerow.html();
     rowhtml = rowhtml.replace("td_Vergoeding_" + huidigekey, "td_AVergoeding_" + nieuwerowkeyval);
     nieuwerow.html(rowhtml);
     nieuwerow.on("click", IngenomenRowClick);  
     $("#ingenomen_grid tbody").append(nieuwerow);
     TotaalEnKnoppen();
}

function NeemTerug(huidigerow)
{    huidigerow.removeClass("bg-success selected_ingenomen_row row_is_active");
     huidigerow.hide();
     TotaalEnKnoppen();
}

function NeemAllesTerug()
{    $.each($('.ingenomen_row.row_is_active'), function(index, row)
                                               {    NeemTerug($(this));
                                               }
           );
     TotaalEnKnoppen();
}

function TotaalEnKnoppen()
{    var totaal = 0;
     var rowcount = 0;
     $.each($('.ingenomen_row.row_is_active'), function(index, row)
                                               {    var keyvalue = $(this).attr('row_key_value');
                                                    var bedrag = $("#td_AVergoeding_" + keyvalue).attr("display_value");
                                                    totaal += parseFloat(bedrag);
                                                    rowcount++;
                                               }
            );

     $("#ingenomen_totaal").html("&euro;&nbsp;" + totaal.toFixed(2));
     if (rowcount < 1)
     {
         $(".ingenomen_action_button").addClass("disabled"); 
         $("#print_inname_bon").addClass("disabled"); 
     }
     else
     {
         $("#print_inname_bon").removeClass("disabled"); 
         $("#button_remove_all").removeClass("disabled"); 
     }
}

function PrintBon()
{    var print_rows = $(".ingenomen_row.row_is_active");   
     if (print_rows.length < 1)
     {    ShowDialog("warning", "Nog geen apparaten ingenomen.", DoeNiks, null, null);
          return;
     }  
     SaveRow();
     var key_value = $(".selected_row").attr('row_key_value');
     var print_window = window.open("printbon.php?inname=" + key_value); 
     print_window.print();
}

function DetailsPost()
{    var NieuweAppIDs = new Array();
     var IDs = new Array();
     $.each($('.ingenomen_row.row_is_active'), function(index, row)
                                               {    var keyvalue = $(this).attr('row_key_value');
                                                    if (parseInt(keyvalue) < 0)
                                                    {    var row_data = JSON.parse($(this).attr('row_data'));
                                                         var app_id = row_data.ID;
                                                         NieuweAppIDs.push(app_id);
                                                    }
                                                    else
                                                    { // Inname blijft in tabel
                                                         IDs.push(keyvalue);
                                                    }
                                               }
            );
     return {
                 NieuweAppIDs:     NieuweAppIDs.join(","),
                 IDs:              IDs.join(","),
                 MasterID:         $(".selected_row").attr('row_key_value')
            };
}
