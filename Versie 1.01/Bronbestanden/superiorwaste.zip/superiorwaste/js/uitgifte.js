function CustomInitDocument() 
{    $(".apparaat_row").on("click", ApparaatRowClick);
               
     $(".ingenomen_row").on("click", IngenomenRowClick);   
     
     $("#button_inname").on("click", function(event) 
                                     {    if (RowSelected("selected_apparaat"))
                                               NeemIn();
                                     }
                           );
     $("#button_remove").on("click", function(event) 
                                     {    if (RowSelected("selected_ingenomen"))
                                          {    var row = $(".selected_ingenomen_row");
                                               NeemTerug(row);
                                          }
                                     }
                           );
     
     $("#button_remove_all").on("click", function(event) 
                                         {    ShowDialog("warning", "Alle apparaten terugnemen?", null, NeemAllesTerug, DoeNiks)
                                         }
                               );
     $("#button_cancel").on("click", function(event) 
                                     {    LoadMainContainer(currentURL);
                                     }
                           );
     
     if ($("#print_uitgifte_bon").length != 0)
     { // Directe uitgifte
          $("#print_uitgifte_bon").on("click", function(event) 
                                               {    SaveUitgifte();    
                                               }
                                     );
          NewRow();
     }
} 

function ApparaatRowClick() 
{    $(".apparaat_row").removeClass("bg-success selected_apparaat_row");
     $(this).addClass("bg-success selected_apparaat_row");
     $(".apparaat_action_button").removeClass("disabled");
}

function IngenomenRowClick() 
{    $(".ingenomen_row").removeClass("bg-success selected_ingenomen_row");
     $(this).addClass("bg-success selected_ingenomen_row");
     $(".ingenomen_action_button").removeClass("disabled");
}

function PrintVrachtbrief()
{    var result = $("#status_result_code").html();
     //[[310]] Begin
     if (result != "success")
          return;
     //[[310]] Einde
     var key_value = $("#status_new_row .table_row").attr('row_key_value');
     var print_window = window.open("printvrachtbrief.php?uitgifte=" + key_value); 
     print_window.print();
}

function SaveUitgifte()
{    var post_values = {
                           row_action:    "insert_row",
                           row_key_value: -1 
                       };
     var columns = JSON.parse($("#table_grid").attr('table_columns'));
     for (var cname in columns)
     {    var elm = $("#" + cname + "_id");
          post_values[cname] = elm.val();
     }
     ExecuteAction(post_values, PrintVrachtbrief); 
}