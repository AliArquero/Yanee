var currentURL = "";

function LoadMainContainer(URL)
{    $("#main_container").load(URL, "", InitDocument); 
     currentURL = URL;
}

function InitDocument() 
{    ShowContainer("grid");
     $(".table_row").on("click", TableRowClick);
     
     $("#button_new").on("click", function(event) 
                                 {    NewRow();
                                 }
                       );
     $("#button_edit").on("click", function(event) 
                                 {    if (RowSelected("selected"))
                                           EditRow();
                                 }
                       );
     $("#button_delete").on("click", function(event) 
                                     {    if (RowSelected("selected"))
                                               ShowDialog("info", "Deze regel werkelijk verwijderen?", 
                                                          null, DeleteRowFromDatabase, DoeNiks);
                                     }
                           );
     $("#button_save").on("click", function(event) 
                                   {    SaveRow();
                                   }
                         );
     $("#button_print").on("click", function(event) 
                                    {    PrintGrid();
                                    }
                       );
     $("#button_cancel").on("click", function(event) 
                                     {    ShowContainer("grid");
                                     }
                           );
     
     $("#button_login").on("click", function(event) 
                                     {    Login();
                                     }
                           );
     
     $("#button_logout").on("click", function(event) 
                                     {    Logout();
                                     }
                           );
     
     $.datetimepicker.setLocale('nl');
     $(".datetime_control").each(function() 
                                 {    $(this).datetimepicker({
                                                                  format:     'd-m-Y H:i'
                                                             }
                                                            );
                                 }
                                );
     
     if (typeof(CustomInitDocument) == "function")
          CustomInitDocument();
}

function TableRowClick() 
{    $(".table_row").removeClass("bg-success selected_row");
     $(this).addClass("bg-success selected_row");
     $(".table_action_button").removeClass("disabled");
}

function RowSelected(rowclass)
{    var row_data = $("." + rowclass + "_row").attr('row_data');
     if (!row_data)
     {    ShowDialog("warning", "Geen regel geselecteerd.", DoeNiks, null, null);
          return false;
     }
     return true;
}

function NewRow()
{    ShowContainer("edit");
     $(".table_row").removeClass("bg-success selected_row");
     var columns = JSON.parse($("#table_grid").attr('table_columns'));
     for (var cname in columns)
     {    var elm = $("#" + cname + "_id");
          var defaultvalue = columns[cname];
          if (defaultvalue != "")
               elm.val(defaultvalue)
          else elm.val(null);
     }
     // Is dit een mastergrid? Zoek naar grids met dit grid als master
     // Zo ja verberg alle details
     var detailgrids = $("[masterclass='table']");
     if (!detailgrids)
          return;
     $.each(detailgrids, function(index, grid) 
                         {    var tableID = $(this).attr("id");
                              $.each($("#" + tableID + " tbody tr"), function(trindex, tr)
                                                                     {    $(this).hide();
                                                                          $(this).removeClass("row_is_active");
                                                                     }
                                    )
                         }
            );
}

function EditRow()
{    ShowContainer("edit");
     var row = JSON.parse($(".selected_row").attr('row_data'));
     for (var index in row) 
     {    var elm = $("#" + index + "_id");
          if (elm.length != 0)
          { // Alleen de elementen met de juiste naam van een waarde voorzien
               elm.val(row[index]);
          }
     }
     // Is dit een mastergrid? Zoek naar grids met dit grid als master
     // Zo ja verberg alle details die niet bij dit mastergridrecord horen
     var detailgrids = $("[masterclass='table']");
     if (!detailgrids)
          return;
     var masterkeyvalue = $(".selected_row").attr('row_key_value');
     $.each(detailgrids, function(index, grid) 
                         {    var masterfield = $(this).attr("masterfieldname");
                              var tableID = $(this).attr("id");
                              $.each($("#" + tableID + " tbody tr"), function(trindex, tr)
                                                                     {    var rowdata = JSON.parse($(this).attr('row_data'));
                                                                          var showthis = false;
                                                                          for (var index in rowdata) 
                                                                          {    if ((index == masterfield) &&
                                                                                   (rowdata[index] == masterkeyvalue))
                                                                               {    showthis = true;
                                                                                    break;
                                                                               }
                                                                          }
                                                                          if (showthis)
                                                                          {    $(this).show();
                                                                               $(this).addClass("row_is_active");

                                                                          }
                                                                          else 
                                                                          {    $(this).hide();
                                                                               $(this).removeClass("row_is_active");
                                                                          }
                                                                     }
                                    )
                         }
            );
     AfterShownDetails();
}

function AfterShownDetails()
{ // Override in details scripts
     return false;
}

function DetailsPost() 
{ // Override in details scripts
     return;
}

function SaveRow()
{    var detailspost = DetailsPost(); 
     var row_data = $(".selected_row").attr('row_data');
     if (!row_data)
     { // Insert nieuwe gegevens   
          var post_values = {
                                 row_action:    "insert_row",
                                 row_key_value: -1 
                            };
          var columns = JSON.parse($("#table_grid").attr('table_columns'));
          for (var cname in columns)
          {    var elm = $("#" + cname + "_id");
               post_values[cname] = elm.val();
          }
          $.each(detailspost, function(index, detail) 
                              {    post_values[index] = detail;
                              }
                );
          ExecuteAction(post_values, InsertNewRowInGrid); 
     }
     else
     { // Update bestaande gegevens
          var key_value = $(".selected_row").attr('row_key_value');
          var post_values = {
                                 row_action:    "save_row",
                                 row_key_value: key_value 
                            };
          var row = JSON.parse(row_data);
          for (var index in row) 
          {    var elm = $("#" + index + "_id");
               if (elm.length != 0)
               { // Alleen de elementen met de juiste naam toevoegen aan POST
                    post_values[index] = elm.val();
               }
          }
          $.each(detailspost, function(index, detail) 
                              {    post_values[index] = detail;
                              }
                );
          ExecuteAction(post_values, UpdateCurrentRowInGrid);                  
     }
}

function DeleteRowFromDatabase()
{    var key_value = $(".selected_row").attr('row_key_value');
     var post_values = {
                           row_action:    "delete_row",
                           row_key_value: key_value
                       };
     ExecuteAction(post_values, RemoveCurrentRowFromGrid);                  
}

function RemoveCurrentRowFromGrid()
{    var result = $("#status_result_code").html();
     if (result != "success")
          return;
     LoadMainContainer(currentURL);
}

function InsertNewRowInGrid()
{    var result = $("#status_result_code").html();
     if (result != "success")
          return;
     LoadMainContainer(currentURL);
}

function UpdateCurrentRowInGrid()
{    var result = $("#status_result_code").html();
     if (result != "success")
          return;
     LoadMainContainer(currentURL);
}

function ExecuteAction(post_values, afterAction)
{    $("#status_container").load(currentURL, post_values, function()
                                                               {    ShowContainer("grid");
                                                                    ShowDialog($("#status_result_code").html(), 
                                                                               $("#status_result_msg").html(), afterAction, null, null);
                                                               }
                                ); 
}

function ShowContainer(container)
{    
     $.each(["grid", "edit", "dialog"], 
            function(index, cntnr) 
            {    if (cntnr == container)
                      $("#" + cntnr + "_container").show()
                 else $("#" + cntnr + "_container").hide();
            }
           );
}

function Login()
{
     var post_values = {
                           uname: $("#userName").val(),
                           pword: $("#userPassword").val()
                       };
                       
     $("#status_container").load("remaslogin.php", post_values, function()
                                                                {    var status = $("#status_result_code").html();
                                                                     if (status == "success")
                                                                     {    $("#menu_knop_inloggen").addClass('hidden');
                                                                          $("#menu_knop_uitloggen").removeClass('hidden');
                                                                          var user = JSON.parse($("#status_result_msg").html());
                                                                          $("#ingelogd_als").html("Ingelogd als " + user.mNaam);
                                                                          ZetMenuKnoppen(user);
                                                                          LoadMainContainer("logout.php"); 
                                                                     }
                                                                     else
                                                                          ShowDialog(status, $("#status_result_msg").html(), DoeNiks, null, null);
                                                                }
                                ); 
}

function Logout()
{
     $("#status_container").load("remaslogout.php", null, function()
                                                                {    var status = $("#status_result_code").html();
                                                                     if (status == "success")
                                                                     {    $(".menu_knop").addClass('hidden');
                                                                          $("#menu_knop_uitloggen").addClass('hidden');
                                                                          $("#menu_knop_inloggen").removeClass('hidden');
                                                                          $("#menu_knop_inloggen").addClass('active');
                                                                          $("#ingelogd_als").empty();
                                                                          LoadMainContainer("home.php"); 
                                                                     }
                                                                }
                                ); 
}

function ZetMenuKnoppen(user)
{
     $(".menu_knop").addClass('hidden');
     var schermen = user.schermen.split(",");
     $.each(schermen, 
            function(index, knop) 
            {    knopid = "#menu_knop_" + knop;
                 $(knopid).removeClass('hidden')
            }
           );
}

function DoeNiks()
{
}

function PrintGrid()
{
     $(".table_action_button").hide();
     var print_window = window.open(""); 
     print_window.document.write($("#grid_container").html());
     print_window.print();
     $(".table_action_button").show();
}

function ShowDialog(status = "danger", tekst = "Onbekende melding", okClick, yesClick, noClick)
{    var settings = {
                        resizable: false,
                        position:  { 
                                         my: "center", 
                                         at: "top" 
                                   },
                        modal:     true,
                        title:     $("#table_grid").attr("table_title"),
                        open:      function() 
                                   {    var msg = '<div role="alert" class="alert alert-' + status + '">' +
                                                  tekst +
                                                  '</div>';
                                        $(this).html(msg);
                                        $(this).closest(".ui-dialog").find(".ui-dialog-titlebar-close").hide();
                                        $(this).closest(".ui-dialog").addClass("alert alert-success");
                                   },
                        buttons:   {}
                    };
    
     if (okClick !== null)
     {    settings.buttons["Ok"] = function() 
                                         {
                                              $( this ).dialog( "close" );
                                              okClick();
                                         }
     };
     if (yesClick !== null)
     {    settings.buttons["Ja"] = function() 
                                         {
                                              $( this ).dialog( "close" );
                                              yesClick();
                                         }
     };
     if (noClick !== null)
     {    settings.buttons["Nee"] = function() 
                                         {
                                              $( this ).dialog( "close" );
                                              okClick();
                                         }
     };
     $( "#modal_dialog" ).dialog(settings);
};

$(document).ready(function()
                  {    $(".menu_knop").on("click", function()
                                                    {    $(".menu_knop").removeClass("bg-success");
                                                         $(this).addClass("bg-success");
                                                    }
                                          );
                       LoadMainContainer("home.php"); // Initieel de home pagina laden
                  }
                 ); 
