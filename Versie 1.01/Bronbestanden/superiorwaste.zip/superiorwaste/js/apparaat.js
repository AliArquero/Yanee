function CustomInitDocument() 
{    ShowOAppContainer("grid");
     $(".oapparaat_row").on("click", OApparaatRowClick);
               
     $("#button_oapp_new").on("click", function(event) 
                                        {    NieuweRegel();
                                        }
                              );
     $("#button_oapp_delete").on("click", function(event) 
                                           {    if (RowSelected("selected_oapparaat"))
                                                {    var row = $(".selected_oapparaat_row");
                                                     VerwijderRegel(row);
                                                }
                                           }
                                  );
     
     $("#button_oapp_edit").on("click", function(event) 
                                         {    if (RowSelected("selected_oapparaat"))
                                              {    var row = $(".selected_oapparaat_row");
                                                   WijzigRegel(row);
                                              }
                                         }
                               );    
     $("#button_oapp_ok").on("click", function(event) 
                                       {    UpdateOApparaat();
                                       }
                             );    
     $("#button_oapp_cancel").on("click", function(event) 
                                           {    ShowOAppContainer("grid");
                                           }
                                  );    
} 

function ShowOAppContainer(container)
{    $.each(["grid", "edit"], 
            function(index, cntnr) 
            {    if (cntnr == container)
                      $(".oapparaat_" + cntnr + "_container").show()
                 else $(".oapparaat_" + cntnr + "_container").hide();
            }
           );
}

function AfterShownDetails()
{ // Override van function.js --> AfterShownDetails()
     TotaalPercentage();
}

function OApparaatRowClick() 
{    $(".oapparaat_row").removeClass("bg-success selected_oapparaat_row");
     $(this).addClass("bg-success selected_oapparaat_row");
     $(".oapparaat_action_button").removeClass("disabled");
}

function NieuweRegel()
{    $("#button_oapp_ok").addClass("oapparaat_new");
     ShowOAppContainer("edit");
     $(".oapparaat_row").removeClass("bg-success selected_oapparaat_row");
     var columns = JSON.parse($("#oapparaat_grid").attr('table_columns'));
     for (var cname in columns)
     {    var elm = $("#" + cname + "_id");
          var defaultvalue = columns[cname];
          if (defaultvalue != "")
               elm.val(defaultvalue)
          else elm.val(null);
     }
}

function VerwijderRegel(huidigerow)
{    huidigerow.removeClass("bg-success selected_oapparaat_row row_is_active");
     huidigerow.hide();
     TotaalPercentage();
}

function WijzigRegel()
{    $("#button_oapp_ok").removeClass("oapparaat_new");
     ShowOAppContainer("edit");
     var row = JSON.parse($(".selected_oapparaat_row").attr('row_data'));
     for (var index in row) 
     {    var elm = $("#" + index + "_id");
          if (elm.length != 0)
          { // Alleen de elementen met de juiste naam van een waarde voorzien
               elm.val(row[index]);
          }
     }
}

function TotaalPercentage()
{    var som = 0;
     $.each($('.oapparaat_row.row_is_active'), function(index, row)
                                                {    var keyvalue = $(this).attr('row_key_value');
                                                     var percentage = $("#td_Percentage_" + keyvalue).attr("display_value");
                                                     som += parseInt(percentage);
                                                }
            );
     var totaal = $("#oapp_totaal_container");
     totaal.removeClass("bg-success bg-danger");
     if (som != 100)
          totaal.addClass("bg-danger")
     else totaal.addClass("bg-success");
     $("#oapp_totaal").html(som + "%");
}

function DetailsPost()
{    var OnderdelenNieuw = new Array();
     var Onderdelen = new Array();
     $.each($('.oapparaat_row.row_is_active'), function(index, row)
                                                {    var row_data = JSON.parse($(this).attr('row_data'));
                                                     var keyvalue = $(this).attr('row_key_value');
                                                     if (parseInt(keyvalue) < 0)
                                                     { // Nieuw onderdeel toevoegen   
                                                          OnderdelenNieuw.push(row_data.OnderdeelID + "," + row_data.Percentage);
                                                     }
                                                     else
                                                     { // Onderdeel blijft in tabel (mogelijk gewijzigd)
                                                          Onderdelen.push(keyvalue + "," + row_data.OnderdeelID + "," + row_data.Percentage);
                                                     }
                                                }
            );
     return {
                 OnderdelenNieuw: OnderdelenNieuw.join(";"),
                 Onderdelen:      Onderdelen.join(";"),
                 MasterID:        $(".selected_row").attr('row_key_value')
            };
}

function UpdateOApparaat()
{    var isnieuw = $("#button_oapp_ok").hasClass("oapparaat_new");
     if (isnieuw)
     {    var rowkeyval = 0;
          $.each($('.oapparaat_row.row_is_active'), function(index, row)
                                                     {    var keyvalue = $(this).attr('row_key_value');
                                                          if (parseInt(keyvalue) < rowkeyval)
                                                          {    rowkeyval = keyvalue;
                                                          }
                                                     }

                );
          rowkeyval--;
     }
     else
     {    rowkeyval = $('.selected_oapparaat_row').attr('row_key_value');
     }
                          
     var rowdata = {
                         ID:          rowkeyval,
                         ApparaatID:  $(".selected_row").attr('row_key_value'),
                         OnderdeelID: $("#OnderdeelID_id").val(),
                         Percentage:  $("#Percentage_id").val()
                   }
     var onderdtext = $("#OnderdeelID_id option:selected").text();
     var perctext = $("#Percentage_id").val();
     tds = "<td id='td_OnderdeelID_" + rowkeyval + "'" +
           " display_value='" + onderdtext + "'>" + 
                onderdtext + 
           "</td>" +  
           "<td id='td_Percentage_" + rowkeyval + "'" +
           " display_value='" + perctext + "'>" + 
                perctext + 
           "</td>"
     if (isnieuw)
     {
          $('#oapparaat_grid > tbody:last-child').append('<tr class="new_oapparaat_row">' + 
                                                                tds  +
                                                          '</tr>');
          var nieuwerow = $('.new_oapparaat_row');
          nieuwerow.removeClass('new_oapparaat_row');
          nieuwerow.on("click", OApparaatRowClick); 
          $(".oapparaat_action_button").removeClass("disabled");
          nieuwerow.attr('row_key_value', rowkeyval);
          nieuwerow.addClass("row_is_active bg-success oapparaat_row selected_oapparaat_row");
     }
     else
     {    nieuwerow = $('.selected_oapparaat_row');
          nieuwerow.html(tds);
     }
     nieuwerow.attr('row_data', JSON.stringify(rowdata));
     TotaalPercentage();
     ShowOAppContainer("grid");
}
