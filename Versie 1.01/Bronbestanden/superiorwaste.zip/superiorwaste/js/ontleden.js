function CustomInitDocument() 
{    $(".apparaatspecs_row").on("click", AppSpecRowClick);   

     $("#button_ontleed_ok").on("click", function(event) 
                                         {    ShowDialog("warning", "De onderdelen van dit apparaat werkelijk verwerken?", 
                                                          null, Ontleden, DoeNiks);
                                         }
                               );
     $("#apparaatspecs_button_new").on("click", function(event) 
                                                 {    NieuwOnderdeel();
                                                 }
                                       );
     $("#apparaatspecs_button_edit").on("click", function(event) 
                                                 {    if (RowSelected("selected_apparaatspecs"))
                                                           PasAanOnderdeel();
                                                 }
                                       );
     $("#apparaatspecs_button_delete").on("click", function(event) 
                                                   {    if (RowSelected("selected_apparaatspecs"))
                                                            Verwijder();
                                                   }
                                       );
     $("#apparaatspecs_button_save").on("click", function(event) 
                                                 {    SaveAppSpec();
                                                 }
                                       );
     $("#apparaatspecs_button_cancel").on("click", function(event) 
                                                   {    CancelAppSpec();
                                                   }
                                     );
     $("#Percentage_id").on("change", function(event) 
                                                   {    VulGewichtGram($(this).val());          
                                                   }
                                     );
     $(".grapparaat_edit_container").hide();
} 

function CancelAppSpec() 
{    $(".grapparaat_edit_container").hide();
     $(".grapparaat_grid_container").show();  
}

function SaveAppSpec()
{    var onderdeel = $("#OnderdeelID_id option:selected").text();
     var percentage = $("#Percentage_id").val();
     var gewicht = $("#Gewicht_id").attr("display_value");
     
     if ($("#apparaatspecs_grid").hasClass('nieuw'))
     { // Nieuw onderdeel toevoegen   
          var rowkeyval = 0;
          $.each($('.apparaatspecs_row.row_is_active'), function(index, row)
                                                        {    var keyvalue = $(this).attr('row_key_value');
                                                             if (parseInt(keyvalue) < rowkeyval)
                                                             {    rowkeyval = keyvalue;
                                                             }
                                                        }
                );
          rowkeyval--;
          tds = "<td id='td_OnderdeelID_" + rowkeyval + "'" +
                "    display_value='" + onderdeel + "'>" + 
                      onderdeel + 
                "</td>" +  
                "<td id='td_Percentage_" + rowkeyval + "'" +
                "    class='text-right'" + 
                "    display_value='" + percentage + "'>" + 
                      percentage + 
                "</td>" +
                "<td id='td_Gewicht_" + rowkeyval + "'" +
                "    class='text-right'" + 
                "    display_value='" + gewicht + "'>" + 
                      (parseInt(gewicht) / 1000).toFixed(3) + 
                "</td>"
                
          $('#apparaatspecs_grid > tbody:last-child').append('<tr class="new_apparaatspecs_row">' + 
                                                                   tds  +
                                                             '</tr>');

          var nieuwerow = $('.new_apparaatspecs_row');
          nieuwerow.removeClass('new_apparaatspecs_row');
          nieuwerow.on("click", AppSpecRowClick); 
          $(".apparaatspecs_action_button").removeClass("disabled");
          nieuwerow.attr('row_key_value', rowkeyval);
          nieuwerow.addClass("row_is_active bg-success apparaatspecs_row selected_apparaatspecs_row");
     }
     else
     {    var key_value = $(".selected_apparaatspecs_row").attr('row_key_value');
          $("#td_OnderdeelID_" + key_value).html(onderdeel);
          $("#td_Percentage_" + key_value).html(percentage);
          $("#td_Gewicht_" + key_value).html(gewicht);
          $("#td_OnderdeelID_" + key_value).attr("display_value", onderdeel);
          $("#td_Percentage_" + key_value).attr("display_value", percentage);
          $("#td_Gewicht_" + key_value).attr("display_value", gewicht);
     }
     var row_data = {};
     row_data["OnderdeelID"] = $("#OnderdeelID_id").val();
     row_data["Percentage"] = $("#Percentage_id").val();
     row_data["Gewicht"] = $("#Gewicht_id").attr("display_value");
     
     $(".selected_apparaatspecs_row").attr('row_data', JSON.stringify(row_data));
     
     CancelAppSpec();  // [[290]] Terug naar Grid   
}

function VulGewichtGram(percentage)
{    var key_value = $(".selected_apparaatspecs_row").attr('row_key_value');
     var approw = JSON.parse($(".selected_row").attr('row_data'));
     var gewicht = Math.round(approw.GewichtGram * $("#Percentage_id").val() / 100);
     $("#td_Gewicht_" + key_value).html(gewicht);    
     $("#Gewicht_id").val(gewicht);    
     $("#Gewicht_id").attr("display_value", gewicht);    
}

function NieuwOnderdeel()
{    ShowEditContainer();
     $(".selected_apparaatspecs_row").removeClass(" bg-success selected_apparaatspecs_row");
     $("#apparaatspecs_grid").addClass('nieuw');
     var columns = JSON.parse($("#apparaatspecs_grid").attr('table_columns'));
     for (var cname in columns)
     {    var elm = $("#" + cname + "_id");
          var defaultvalue = columns[cname];
          if (defaultvalue != "")
               elm.val(defaultvalue)
          else elm.val(null);
          elm.attr("display_value", elm.val());
     }
}

function PasAanOnderdeel()
{    ShowEditContainer();
     $("#apparaatspecs_grid").removeClass('nieuw');
     var row = JSON.parse($(".selected_apparaatspecs_row").attr('row_data'));
     if (!row)
     {    NieuwOnderdeel();
          return;
     }
     
     for (var index in row) 
     {    var elm = $("#" + index + "_id");
          if (elm.length != 0)
          { // Alleen de elementen met de juiste naam van een waarde voorzien
               elm.val(row[index]);
               elm.attr("display_value", row[index]);
          }
     }
}
function ShowEditContainer()
{    $(".grapparaat_grid_container").hide();
     $(".grapparaat_edit_container").show();
}     

function Verwijder()
{    $(".selected_apparaatspecs_row").remove();
}

function AppSpecRowClick() 
{    $(".apparaatspecs_row").removeClass("bg-success selected_apparaatspecs_row");
     $(this).addClass("bg-success selected_apparaatspecs_row");
     $(".apparaatspecs_action_button").removeClass("disabled");
}


function Ontleden() 
{    var innamedata= JSON.parse($(".selected_row").attr('row_data'));
     var gewichten = {};
     $.each($(".apparaatspecs_row.row_is_active"), function(index, detail) 
                                                   {    var row_data = JSON.parse($(this).attr('row_data'));
                                                        if (!gewichten[row_data.OnderdeelID])
                                                             gewichten[row_data.OnderdeelID] = parseInt(row_data.Gewicht)
                                                        else gewichten[row_data.OnderdeelID] += parseInt(row_data.Gewicht);
                                                   }
           );                                                                      
     var post_values = {
                            row_action: "save_row",
                            innameID:   innamedata.IID,
                            apparaatID: innamedata.AID,
                            gewichten:  JSON.stringify(gewichten)
                       };
                       
     ExecuteAction(post_values, RemoveApparaatFromGrid);     
}

function RemoveApparaatFromGrid()
{    var result = $("#status_result_code").html();
     if (result != "success")
          return;
     LoadMainContainer(currentURL);
}
